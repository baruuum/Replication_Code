#ifndef DFS_H
#define DFS_H

//' Depth-first-search on sparse Armadillo matrices
//' 
//' @param v vertex index
//' @param comp current component index
//' @param res reference to component membership vector
//' @param x adjacency matrix
//' @return void
inline void dfs_arma_sp(
        arma::uword v,
        arma::uword comp,
        arma::uvec &res,
        const arma::sp_umat &x
)
{
    
    res(v) = comp;
    arma::sp_umat::const_col_iterator j = x.begin_col(v);
    
    for (; j != x.end_col(v); ++j)
        if (!res(j.row()))
            dfs_arma_sp(j.row(), comp, res, x);
        
    return;
        
}

#endif
