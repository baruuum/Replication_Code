#ifndef SPARSEGLM_H
#define SPARSEGLM_H

#include <RcppEigen.h>

namespace sparseglm {

    using Eigen::MatrixXd;
    using Eigen::VectorXd;
    using Eigen::ArrayXd;
    using Eigen::SparseQR;
    using Eigen::LeastSquaresConjugateGradient;
    using Eigen::LeastSquareDiagonalPreconditioner;
    using std::numeric_limits;
    
    typedef Eigen::SparseMatrix<double> SpMat;

    class SparseGLM {

    protected:

        VectorXd m_y;       // outcome vector
        SpMat m_x;          // model matrix
        int m_N, m_K;       // row and column of m_X
        VectorXd m_b;       // reg coefficients
        ArrayXd m_mu;       // predictions
        ArrayXd m_pseudo_y; // pseudo-responses
        double m_dev;       // deviance
        bool m_type;        // type of decomposition to use
        double m_tol;       // tolerance
        int m_iter;         // iteration counter
        int m_maxit;        // max no of iterations
        int m_verbose;      // verbosity
        
        void update_fitted() { m_mu = (m_x * m_b).array().exp(); };
        void update_beta_wls();
        void update_deviance();
        
        double m_ll0;
        
    public:

        // constructor
        SparseGLM(
            const VectorXd &y, 
            const SpMat &x, 
            int type,
            double tol,
            int maxit,
            int verbose)
        : m_y(y),
          m_x(x),
          m_N(m_x.rows()),
          m_K(m_x.cols()),
          m_b(m_x.cols()),
          m_mu(y.array() + 0.1),
          m_pseudo_y(m_x.rows()),
          m_dev(numeric_limits<double>::infinity()),
          m_type(type),
          m_tol(tol),
          m_iter(0L),
          m_maxit(maxit),
          m_verbose(verbose) 
        {
            
            m_ll0 = 0.0;
            for (int i = 0; i < m_N; ++i)
                if (m_y(i) > 0.0)
                    m_ll0 += R::dpois(m_y(i), m_y(i), true);   
                
            
        }

        // member functions
        void fit();

        VectorXd get_beta() { return m_b; };
        double get_deviance() { return m_dev; };
        MatrixXd get_fitted() { return m_mu; };
        int get_iterations() { return m_iter + 1L; };
        double get_loglik() { return m_ll0 - 0.5 * m_dev; };
        
    };

    

    //' Weighted least squares regression
    //'
    //' @param y outcome vector
    //' @param x model matrix
    //' @param w weight vector
    //' @param whether to use cholesky factorization in calculating the solution; defaults to \code{false}, which uses the Householder QR decomposition with column pivoting.
    //' @return coefficients from WLS regression
    //' @details Calculates \eqn{(X'WX)^{-1}X'Wy}. The first column of \code{x} should be a column of ones.
    void SparseGLM::update_beta_wls() {

        SpMat xw = m_mu.sqrt().matrix().asDiagonal() * m_x;

        if (m_type == 0) {

            SparseQR<SpMat, Eigen::COLAMDOrdering<int>> SQR(xw);

            if (SQR.info() != Eigen::Success)
                Rcpp::stop("QR decomposition failed");

            m_b = SQR.solve((m_pseudo_y * m_mu.sqrt()).matrix());

            if (SQR.info() != Eigen::Success)
                Rcpp::stop("QRSolver solving failed");

        } else {

            LeastSquaresConjugateGradient<SpMat, LeastSquareDiagonalPreconditioner<double>> CG(xw);

            if (CG.info() != Eigen::Success)
                Rcpp::stop("QR decomposition failed");

            m_b = CG.solve((m_pseudo_y * m_mu.sqrt()).matrix());

            if (CG.info() != Eigen::Success)
                Rcpp::stop("QRSolver solving failed");

        }

        return;

    }


    void SparseGLM::update_deviance() {

        double f(0.0);
        
        for (int i = 0; i < m_N; ++i) {

            f += m_mu(i);
            
            if (m_y(i) > 0.0)
                f += m_y(i) * (log(m_y(i)) - log(m_mu(i)) - 1.0);
            
        }

        m_dev = 2.0 * f;

        return;

    }


    //' IRLS algorithm for Poisson distributed outcome
    //'
    //' @param b initial value of regression coefficients
    //' @param y outcome vector
    //' @param x model matrix (either \code{MatrixXd} or \code{SparseMatrix<double>})
    //' @param tol tolerance
    //' @param maxit maximum iterations
    //' @param cholesky whether to use the cholesky factorization in wls procedure
    void SparseGLM::fit()
    {

        double dev_old;

        for (; m_iter < m_maxit; ++m_iter) {

            dev_old = m_dev;
            m_pseudo_y  = m_mu.log() + (m_y.array() - m_mu) / m_mu;

            update_beta_wls();
            update_fitted();
            update_deviance();

            if (m_verbose > 0 && (m_iter % m_verbose == 0))
                Rcpp::Rcout << "iteration : " << m_iter + 1L <<
                    ", deviance : " << m_dev << std::endl;


            if ((dev_old - m_dev) < m_tol * dev_old)
                break;

        }

        if (m_iter == m_maxit)
            Rcpp::Rcout << "Warning: maxit reached" << std::endl;

        return;

    }

}

#endif
