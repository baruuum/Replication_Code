## ------------------------------------------------------------------
## These are just sanity checks
## For unit-test results, see ./local_tests/ directory
## ------------------------------------------------------------------

library(sbmob)
library(Matrix)

## ------------------------------------------------------------------
## Setup
## ------------------------------------------------------------------

tol_elbo_hist = -2 * 1e-7

# helper functions
normalize_one = function(x) {
    x / sum(x)
}

## ------------------------------------------------------------------
## Simulate data & create initial values
## ------------------------------------------------------------------

set.seed(42)

n = 50
G = 3
lalpha = rnorm(n - 1)
lbeta  = rnorm(n - 1)
ldelta = rnorm(n - 1, 5, 1)
lpsi   = matrix(rnorm(G * G, 4, 1), nrow = G)
lpi = rep(1, 3) |> normalize_one() |> log()

# simulate data
simres = sim_sbm_poisson(
    lpsi = lpsi,
    lpi = lpi,
    lalpha = c(0, lalpha),
    lbeta = c(0, lbeta)
)
mobmat = simres$mobmat
# diag(mobmat) = 0

dat = mobmat_to_dat(mobmat)

inits = create_inits_spectral(
    x = dat,
    G = G,
    D = G - 1,
    sparse = TRUE,
    symmetrize = 2,
    normalized = TRUE,
    verbose = 0
)

# get initial values
lxi_inits = apply(inits$dist, 1L, function(w) {
    tmp = exp(-w^2); log(tmp) - log(sum(tmp))
}) |> t()



## ------------------------------------------------------------------
## Fit models
## ------------------------------------------------------------------

# control params
clist = list(
    maxit  = 100,
    tol = 1e-10,
    estep_maxit = 100,
    estep_tol = 1e-10,
    mstep_m = 8,
    mstep_epsilon = 1e-10,
    mstep_past = 1,
    mstep_delta = 1e-10,
    mstep_maxit = 300,
    mstep_maxlinesearch = 50,
    stable_density_calc = FALSE,
    debug = FALSE
)

# note: note that results between dense and sparse will be different when
#       using either "spectral_fixed" or "spectral_random" as
#       gen_inits option. The reason being that if sparse == TRUE,
#       arma::eigs_sym instead of arma::eig_sym is used in the eigen-
#       decomposition to generate initial values

# check dense == sparse for provided initial values
set.seed(12)
res = sbm(
    dat,
    inits = lxi_inits, 
    nblocks = G,
    sparse = FALSE,
    control = clist,
    verbose = 0
)
set.seed(12)
res_sparse = sbm(
    dat,
    inits = lxi_inits,
    nblocks = G,
    sparse = TRUE,
    control = clist,
    verbose = 0
)
expect_equal(res$elbo, res_sparse$elbo)

# par(mfrow = c(2, 3), mar = rep(2, 4))
# plot(res$lalpha, res_sparse$lalpha); abline(0, 1, col = "red")
# plot(res$lbeta, res_sparse$lbeta); abline(0, 1, col = "red")
# plot(res$lpsi, res_sparse$lpsi); abline(0, 1, col = "red")
# plot(res$lpi, res_sparse$lpi); abline(0, 1, col = "red")
# plot(res$lxi, res_sparse$lxi); abline(0, 1, col = "red")

set.seed(12)
clist$stable_density_calc = TRUE
res_stable = sbm(
    dat,
    inits = lxi_inits, 
    nblocks = G,
    control = clist,
    verbose = 0
)
set.seed(12)
res_sparse_stable = sbm(
    dat,
    inits = lxi_inits, 
    nblocks = G,
    sparse = TRUE,
    control = clist,
    verbose = 0
)
expect_equal(res$elbo, res_stable$elbo)
expect_equal(res_sparse$elbo, res_stable$elbo)
expect_equal(res_sparse_stable$elbo, res_sparse$elbo)

# check dense == sparse for random initial values
clist$stable_density_calc = FALSE
set.seed(1213)
res2 = sbm(
    dat,
    gen_inits = "random",
    nblocks = G,
    control = clist,
    verbose = 0
)
set.seed(1213)
res_sparse2 = sbm(
    dat,
    gen_inits = "random",
    nblocks = G,
    sparse = TRUE,
    control = clist,
    verbose = 0
)
expect_equal(res2$elbo, res_sparse2$elbo)

# check that elbo is increasing
expect_true(all(diff(res$elbo_hist) >= tol_elbo_hist))
expect_true(all(diff(res2$elbo_hist) >= tol_elbo_hist))

# check elbo for gen_inits
res3 = sbm(
    dat,
    gen_inits = "spectral",
    nblocks = G,
    control = clist,
    verbose = 0
)
res4 = sbm(
    dat,
    gen_inits = "spectral",
    nblocks = G,
    sparse = TRUE,
    control = clist,
    verbose = 0
)
expect_true(all(diff(res3$elbo_hist) >= tol_elbo_hist))
expect_true(all(diff(res4$elbo_hist) >= tol_elbo_hist))



## ------------------------------------------------------------------
## Fit models without row- and column-effects
## ------------------------------------------------------------------

# check dense == sparse for provided initial values
set.seed(1213)
res = sbm(
    dat,
    inits = lxi_inits,
    nblocks = G,
    model = "diagonal",
    control = clist,
    verbose = 0
)

set.seed(1213)
res_sparse = sbm(
    dat,
    inits = lxi_inits,
    nblocks = G,
    sparse = TRUE,
    model = "diagonal",
    control = clist,
    verbose = 0
)

expect_equal(res$elbo, res_sparse$elbo)

# check dense == sparse for random initial values
set.seed(12)
res2 = sbm(
    dat,
    gen_inits = "random",
    nblocks = G,
    model = "diagonal",
    control = clist,
    verbose = 0
)
set.seed(12)
res_sparse2 = sbm(
    dat,
    gen_inits = "random" ,
    nblocks = G,
    sparse = TRUE,
    model = "diagonal",
    control = clist,
    verbose = 0
)
expect_equal(res2$elbo, res_sparse2$elbo)

# check that elbo is increasing
expect_true(all(diff(res$elbo_hist) >= tol_elbo_hist))
expect_true(all(diff(res2$elbo_hist) >= tol_elbo_hist))

# check elbo for gen_inits
res3 = sbm(
    dat,
    gen_inits = "spectral",
    nblocks = G,
    model = "diagonal",
    control = clist,
    verbose = 0
)
res4 = sbm(
    dat,
    gen_inits = "random",
    nblocks = G,
    model = "diagonal",
    sparse = TRUE,
    control = clist,
    verbose = 0
)
expect_true(all(diff(res3$elbo_hist) >= tol_elbo_hist))
expect_true(all(diff(res4$elbo_hist) >= tol_elbo_hist))


## ------------------------------------------------------------------
## Check connectedness of graph
## ------------------------------------------------------------------

for (cc in 1:3) {

    # select random node
    nn = sample.int(30, 1)
    mobmat_discon = mobmat
    nn_d = mobmat[nn, nn]
    mobmat_discon[nn, ] = mobmat_discon[, nn] = 0
    mobmat_discon[nn, nn] = nn_d

    dat_discon = mobmat_to_dat(mobmat_discon)

    expect_error(
        sbm(
            dat_discon,
            gen_inits = "random",
            nblocks = G,
            model = "diagonal",
            control = clist,
            verbose = 0
        )
    )

    expect_error(
        sbm(
            dat_discon,
            gen_inits = "random",
            nblocks = G,
            model = "qindep",
            control = clist,
            verbose = 0
        )
    )

}

d_mat =  Matrix::bdiag(mobmat, mobmat) |>
    as.matrix() |>
    mobmat_to_dat()

expect_error(
    sbm(
        d_mat,
        gen_inits = "random",
        nblocks = G,
        model = "diagonal",
        control = clist,
        verbose = 0
    )
)

expect_error(
    sbm(
        d_mat,
        gen_inits = "random",
        nblocks = G,
        model = "qindep",
        control = clist,
        verbose = 0
    )
)

### EOF ###