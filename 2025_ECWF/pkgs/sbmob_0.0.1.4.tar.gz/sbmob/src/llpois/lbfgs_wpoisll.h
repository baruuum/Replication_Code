#ifndef LBFGS_WPOISLL_H
#define LBFGS_WPOISLL_H

#include <RcppEigen.h>
#include <LBFGS.h>
#include "../utils/matrix_lfactorial.h"

namespace wpois {

using Eigen::VectorXd;
using Eigen::MatrixXd;
using Eigen::ArrayXd;
using Eigen::ArrayXXd;
using Eigen::Map;

typedef Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic, Eigen::RowMajor> Rmat;
typedef Eigen::SparseMatrix<double> SpMat;

// -------------------------------------------------------------
// Gradient
// -------------------------------------------------------------

template <typename T>
inline VectorXd calc_grad(
        const T& y,
        const Rmat& lxi,
        const ArrayXd& lalpha,
        const ArrayXd& lbeta,
        const MatrixXd& lpsi,
        const ArrayXd& rowsum_y,
        const ArrayXd& colsum_y
){
    
    int N(lxi.rows()), G(lxi.cols());
    
    MatrixXd xi = lxi.array().exp().matrix();
    MatrixXd psi = lpsi.array().exp().matrix();
    VectorXd alpha = lalpha.exp().matrix();
    VectorXd beta = lbeta.exp().matrix();
    
    MatrixXd w = xi.bottomRows(N - 1L);
    
    MatrixXd xi_a = alpha.asDiagonal() * w;
    xi_a.rowwise() -= xi_a.colwise().sum() + xi.row(0L);
    
    MatrixXd xi_b = beta.asDiagonal() * w;
    xi_b.rowwise() -= xi_b.colwise().sum() + xi.row(0L);
    
    ArrayXd gr_lalpha = rowsum_y +
        alpha.array() * (
                ( w * psi ).array() * xi_b.array()
        ).rowwise().sum();
    
    ArrayXd gr_lbeta = colsum_y +
        beta.array() * (
                ( xi_a * psi ).array() * w.array()
        ).rowwise().sum();
    
    // pad alpha and beta
    VectorXd alpha_full(N), beta_full(N);
    alpha_full << 1.0, alpha;
    beta_full << 1.0, beta;
    
    ArrayXd ab_prod = alpha_full.array() * beta_full.array();
    MatrixXd gr_lpsi = xi.transpose() * y * xi;
    
    for (int g1 = 0; g1 < G; ++g1) {
        
        VectorXd xi1 = xi.col(g1);
        
        for (int g2 = 0; g2 < G; ++g2) {
            
            VectorXd xi2 = xi.col(g2);
            
            double acc = xi1.transpose() * alpha_full * beta_full.transpose() * xi2 - 
                (xi1.array() * xi2.array() * ab_prod).sum();
            
            gr_lpsi(g1, g2) -= psi(g1, g2) * acc;
            
        }
    }

    // Rcpp::Rcout << "N: " << N << std::endl;
    // Rcpp::Rcout << "G: " << G << std::endl;
    // Rcpp::Rcout << "lalpha size: " << gr_lalpha.size() << std::endl;
    // Rcpp::Rcout << "lbeta size: " << gr_lbeta.size() << std::endl;
    // Rcpp::Rcout << "grad gr_lpsi: " << gr_lpsi << std::endl;

    VectorXd gr(2L * (N - 1L) + (G * G));
    gr << gr_lalpha, gr_lbeta, gr_lpsi.reshaped();
    
    return -1.0 * gr;
    
}


// -------------------------------------------------------------
// ELBO
// -------------------------------------------------------------

inline double elbo_theta(
        const MatrixXd& y,
        const Rmat& lxi,
        const ArrayXd& lalpha,
        const ArrayXd& lbeta,
        const MatrixXd& lpsi,
        double lfact_y,
        bool stable
) {
    
    int N(lxi.rows());
    
    Rmat xi = lxi.array().exp().matrix();
    MatrixXd psi = lpsi.array().exp().matrix();
    
    double f(0.0);
    
    for (int j = 0; j < N; ++j) {
        
        VectorXd xi_j = xi.row(j).transpose();
        VectorXd y_j = y.col(j);
        double lbeta_j = (j == 0) ? 0.0 : lbeta(j - 1L);
        
        for (int i = 0; i < N; ++i) {
            
            if (i != j) {
                
                double lambda = lbeta_j;
                
                if (i != 0) 
                    lambda += lalpha(i - 1L);
                
                f -= std::exp(lambda) * xi.row(i) * psi * xi_j;
                
                if (y_j(i) > 0) {
                    
                    f += y_j(i) * (lambda + xi.row(i) * lpsi * xi_j);
                    
                    if (stable)
                        f -= R::lgammafn(y_j(i) + 1.0);
                    
                }
                    
                
            }
            
        }
        
    }
    
    if (stable)
        return -1.0 * f;
    
    return  lfact_y - f;
    
}

inline double elbo_theta(
        const SpMat& y,
        const Rmat& lxi,
        const ArrayXd& lalpha,
        const ArrayXd& lbeta,
        const MatrixXd& lpsi,
        double lfact_y,
        bool stable
) {
    
    int N(lxi.rows());
    Rmat xi = lxi.array().exp().matrix();
    MatrixXd psi = lpsi.array().exp().matrix();
    
    double f(0.0);
    
    for (int j = 0; j < N; ++j) {
        
        VectorXd xi_j = xi.row(j).transpose();
        double lbeta_j = (j == 0) ? 0.0 : lbeta(j - 1);
        
        for (int i = 0; i < N; ++i) {
            
            if (i != j) {
                
                double lambda = lbeta_j;
                
                if (i != 0) 
                    lambda += lalpha(i - 1L);
                
                f -= std::exp(lambda) * xi.row(i) * psi * xi_j;
                                
            } // if

        } // for i

        for (SpMat::InnerIterator it(y, j); it; ++it) {
        
            if (it.row() != it.col()) {

                double lambda = lbeta_j;

                if (it.row() != 0)
                    lambda += lalpha(it.row() - 1L);

                f += it.value() * (lambda + xi.row(it.row()) * lpsi * xi_j);
            
                if (stable)
                    f -= R::lgammafn(it.value() + 1.0);
            
            } // if 
        
        } // for it
        
    } // for j

    if (stable)
        return -1.0 * f;
    
    return  lfact_y - f;
    
}


// -------------------------------------------------------------
// Class def
// -------------------------------------------------------------

template <typename T>
class WPoisLL {
    
private:
    
    const T y;
    const Rmat lxi;
    const int N;
    const int G;
    
    double lfact_y;
    ArrayXd rowsum_y;
    ArrayXd colsum_y;
    
    bool stable;
    
public:
    
    // constructor
    WPoisLL(
        const T& y_, 
        const Rmat& lxi_,
        bool stable_
    ): y(y_), 
       lxi(lxi_), 
       N(lxi_.rows()), 
       G(lxi_.cols()),
       stable(stable_)
    {
        
        lfact_y = stable ? 0.0 : matrix_lfactorial(y);
        rowsum_y = (y * VectorXd::Ones(N)).tail(N - 1L).array();
        colsum_y = (VectorXd::Ones(N).transpose() * y).tail(N - 1L).array();
        
    }
    
    ~WPoisLL(){};
    
    double operator()(const VectorXd& x, VectorXd& grad)
    {
        
        Map<const ArrayXd> lalpha(x.data(), N - 1);
        Map<const ArrayXd> lbeta(x.data() + N - 1, N - 1);
        Map<const MatrixXd> lpsi(x.data() + 2 * (N - 1), G, G);
        
        // gradient of negative elbo
        grad = calc_grad(y, lxi, lalpha, lbeta, lpsi, rowsum_y, colsum_y);
        
        // negative elbo
        return elbo_theta(y, lxi, lalpha, lbeta, lpsi, lfact_y, stable);
        
    }
    
};

} // namespace wpois

extern template class wpois::WPoisLL<Eigen::MatrixXd>;
extern template class wpois::WPoisLL<Eigen::SparseMatrix<double>>;

#endif
