## ------------------------------------------------------------------
## Testing log-linear model with blocks
## ------------------------------------------------------------------

library(sbmob)
library(Matrix)

## ------------------------------------------------------------------
## Setup
## ------------------------------------------------------------------

# helper functions
normalize_one = function(x) { x / sum(x) }

check_models = function(fit1, fit2, formula = FALSE) {

    # coefficients
    expect_equal(fit1$fit$coefficients, fit2$fit$coefficients, check.attributes = FALSE)
    # fitted vals
    expect_equal(fit1$fit$fitted.values, fit2$fit$fitted.values, check.attributes = FALSE)
    # deviance
    expect_equal(fit1$fit$deviance, fit2$fit$deviance)
    # log-likelihood
    expect_equal(fit1$ll, fit2$ll)
    # G2 and X2
    expect_equal(fit1$fit_tab, fit2$fit_tab)
    # Information criteria
    expect_equal(fit1$ic_tab, fit2$ic_tab)
    # formula
    if (formula)
        expect_equal(fit1$formula, fit2$formula)
        
}

## ------------------------------------------------------------------
## Simulate data & create initial values
## ------------------------------------------------------------------

n = 30
G = 3
lalpha = rnorm(n - 1) 
lbeta  = rnorm(n - 1)
ldelta = rnorm(n - 1, 5, 1)
lpsi   = matrix(rnorm(G * G, 4, 1), nrow = G)
lpi = runif(G) |> normalize_one() |> log()

z = 0
while (length(table(z)) != G || !all(table(z) > 1))
    z = sample(1:G, n, replace = TRUE, prob = exp(lpi)) - 1

# simulate data
simres = sim_sbm_poisson(
    lpsi = lpsi, lpi = lpi, lalpha = c(0, lalpha), lbeta = c(0, lbeta), z = z
)
mobmat = simres$mobmat

# fit log-linear model
dat = mobmat_to_dat(mobmat)
fit1 = loglin_blocks(dat, z, sparse_glm = FALSE)
fit2 = loglin_blocks(dat, z, sparse_glm = TRUE)
check_models(fit1, fit2, formula = TRUE)

# AIC (comp. with R version)
expect_equal(AIC(fit1$fit), fit1$ic_tab["AIC", "IC"])
# BIC (comp. with R version)
expect_equal(BIC(fit1$fit), fit1$ic_tab["BIC", "IC"])


# use diff indices (check except formula)
fit22 = loglin_blocks(mobmat_to_dat(mobmat, index = 1), z, sparse_glm = TRUE)
check_models(fit2, fit22)
fit12 = loglin_blocks(mobmat_to_dat(mobmat, index = 1), z, sparse_glm = FALSE)
check_models(fit22, fit12)

# use diff indices for blocks
fit23 = loglin_blocks(mobmat_to_dat(mobmat, index = 0), z + 1, sparse_glm = TRUE)
check_models(fit22, fit23)

### EOF ###
