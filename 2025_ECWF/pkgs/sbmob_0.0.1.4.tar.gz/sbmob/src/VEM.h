#ifndef VEM_H
#define VEM_H

#include "VBase.h"
#include <LBFGS.h>
#include "llpois/lbfgs_wpoisll.h"
#include "utils/expsums.h"

using Eigen::MatrixXd;
using Eigen::VectorXd;
using Eigen::ArrayXd;

typedef Eigen::SparseMatrix<double> SpMat;
typedef Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic, Eigen::RowMajor> Rmat;


template <typename T> 
class VEM : public VBase<T>
{
    
protected:
    
    using VBase<T>::m_y;
    using VBase<T>::m_G;
    using VBase<T>::m_nodes;
    
    using VBase<T>::lxi;
    using VBase<T>::lpsi;
    using VBase<T>::lpi;
    
    VectorXd lalpha;
    VectorXd lbeta;
    
    int m_iter, m_verbose;
    double m_elbo;                      // elbo
    std::vector<double> m_elbo_hist;   // elbo history
    
public:
    
    // constructors
    VEM(
        const T& mobmat, 
        const MatrixXd& lxi_inits, 
        int verbose
    );
    VEM(
        const T& mobmat,
        const MatrixXd& lxi_inits,
        const VectorXd& lalpha_inits,
        const VectorXd& lbeta_inits,
        const MatrixXd& lpsi_inits,
        const VectorXd& lpi_inits,
        int verbose
    );
    
    void estep(int estep_maxit, double estep_tol, bool debug);
    void mstep(int mstep_m, double mstep_epsilon, int mstep_past, double mstep_delta, int mstep_maxit, int mstep_maxlinesearch, bool stable = false, bool debug = false);
    void fit(int maxit, double tol, int estep_maxit, double estep_tol, int mstep_m = 6,
             double mstep_epsilon = 1e-05, int mstep_past = 0, double mstep_delta = 1e-05,
             int mstep_maxit = 300, int mstep_maxlinesearch = 30, bool stable = false, bool debug = false);
    
    VectorXd get_lalpha() const { return lalpha; };
    VectorXd get_lbeta() const { return lbeta; };
    MatrixXd get_lpsi() const { return lpsi; };
    VectorXd get_lpi() const {return lpi; };
    MatrixXd get_lxi() const { return lxi; };
    double get_elbo() const { return m_elbo; };
    std::vector<double> get_elbo_hist() const {return m_elbo_hist; };
    double get_icl(const T& mobmat) const ;
    
    T get_mobmat() const { return m_y; };

    VectorXd get_gradient() {      // for debugging
        
        ArrayXd rowsum_y = (m_y * VectorXd::Ones(m_nodes)).tail(m_nodes - 1L).array();
        ArrayXd colsum_y = (VectorXd::Ones(m_nodes).transpose() * m_y).tail(m_nodes - 1L).array();
        
        return wpois::calc_grad(
            m_y,
            lxi,
            lalpha.array(),
            lbeta.array(),
            lpsi,
            rowsum_y,
            colsum_y
        );
    };
    
};

// specialized templates
template<> void VEM<MatrixXd>::estep(int estep_maxit, double estep_tol, bool debug);
template<> void VEM<SpMat>::estep(int estep_maxit, double estep_tol, bool debug);

// explicit instantiation
extern template class VEM<MatrixXd>;
extern template class VEM<SpMat>;

#endif
