if ( requireNamespace("tinytest", quietly = TRUE) ){

    home = identical(Sys.info()["nodename"], "AS-Soc-bp522-20")
    tinytest::test_package("sbmob", at_home = home)

}
