#ifndef EXPSUMS_H
#define EXPSUMS_H

#include <RcppEigen.h>

using Eigen::VectorXd;
using Eigen::MatrixXd;


//' log-sum-exp (works only for Eigen objects)
template <typename T>
inline double log_sum_exp(const T& x) 
{
    
    double max_exp = x.maxCoeff();
    double y(0.0);

    for (int i = 0; i < x.size() ; ++i)
        y += std::exp(x(i) - max_exp);
        
    return std::log(y) + max_exp;
        
}

inline double log_sum_exp_rcpp_nv(const Rcpp::NumericVector& x) 
{
    
    double max_exp = Rcpp::max(x);
    double y(0.0);
    
    for (int i = 0; i < x.size() ; ++i)
        y += std::exp(x(i) - max_exp);
    
    return std::log(y) + max_exp;
    
}

//' log-sum-exp for two double values
inline double log_add_exp(
        const double x, 
        const double y) 
{
    
    const double d = x - y;
    
    if (d > 0.0)
        return x + std::log1p(std::exp(-d));
    
    return y + std::log1p(std::exp(d));
    
}

//' log-runsum-exp
inline VectorXd log_accu_exp (const VectorXd &x) {
    
    // initialize with x
    VectorXd y(x);
    
    // accumulate probabilities on the log-scale
    for (int i = 1L; i < y.size(); ++i)
        y(i) = log_add_exp(y(i - 1L), y(i));
    
    return y;
    
}

// log(1 - exp(x))
inline double log1mexp(double x) {
    
    using std::exp;
    using std::log;
    
    if (x > 0) {
        
        return R_NaN;
        
    } else if (x > -0.693147) {
        
        return log(-std::expm1(x));  
        
    } else {
        
        return std::log1p(-1.0 * exp(x));
        
    }
    
}

//' log(exp(x) - exp(y))
inline double log_diff_exp(const double x, const double y) {
    
    if (x <= y) {
        
        return (x < R_PosInf && x == y) ? R_NegInf : R_NaN;
        
    }
    
    return x + log1mexp(y - x);
    
}

#endif
