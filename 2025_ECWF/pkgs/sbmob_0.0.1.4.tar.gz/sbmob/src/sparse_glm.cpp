//[[Rcpp::depends(RcppEigen)]]
#include <RcppEigen.h>
#include "SparseGLM/SparseGLM.h"

//' Sparse Poisson GLM
//' 
//' Fits GLM for models with sparse design matrices using QR decomposition or Conjugate Gradient
//' 
//' @param y outcome vector
//' @param x sparse model matrix
//' @param type algorithm to use: either 0 (sparse QR) or 1 (conjugate gradient)
//' @param tol (relative) tolerarnce for convergence
//' @param maxit maximum iterations to use
//' @param verbose verbosity level
//[[Rcpp::export(.sparse_glm)]]
Rcpp::List sparse_glm(
    const Eigen::VectorXd& y,
    const Eigen::SparseMatrix<double>& x,
    int type,
    double tol,
    int maxit,
    int verbose) {
    
    sparseglm::SparseGLM mod(y, x, type, tol, maxit, verbose);
    mod.fit();
    
    return Rcpp::List::create(
        Rcpp::_["coefficients"] = mod.get_beta(),
        Rcpp::_["deviance"] = mod.get_deviance(),
        Rcpp::_["fitted.values"] = mod.get_fitted(),
        Rcpp::_["df.residual"] = y.size() - x.cols(),
        Rcpp::_["loglik"] = mod.get_loglik(),
        Rcpp::_["iter"] = mod.get_iterations()
    );
    
}

// EOF //
