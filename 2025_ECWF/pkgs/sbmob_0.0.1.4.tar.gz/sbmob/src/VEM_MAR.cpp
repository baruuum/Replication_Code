#include "VEM_MAR.h"
// #define DEBUG 1

using Eigen::MatrixXd;
using Eigen::VectorXd;
using Eigen::ArrayXd;
using Eigen::ArrayXi;
using Eigen::ArrayXXd;
using Eigen::RowVectorXd;

typedef Eigen::SparseMatrix<double> SpMat;
typedef Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic, Eigen::RowMajor> Rmat;


// -------------------------------------------------------------
// Constructors 
// -------------------------------------------------------------

template <typename T>
VEM_MAR<T>::VEM_MAR(
    const T& mobmat,     
    const MatrixXd& lxi_inits,
    int verbose
) : VBase<T>::VBase(mobmat, lxi_inits),
    m_iter(0L),
    m_verbose(verbose)
{
    
    lfact_y = matrix_lfactorial(m_y);
    update_elbo();
    m_elbo_hist.push_back(get_elbo());
    
}


template <typename T>
VEM_MAR<T>::VEM_MAR(
    const T& mobmat,
    const MatrixXd& lxi_inits,
    const MatrixXd& lpsi_inits,
    const VectorXd& lpi_inits,
    int verbose
) : VBase<T>::VBase(mobmat, lxi_inits, lpsi_inits, lpi_inits),
    m_iter(0L), 
    m_verbose(verbose)
{
    
    lfact_y = matrix_lfactorial(m_y);
    
    update_elbo();
    m_elbo_hist.push_back(get_elbo());
    
}

template <typename T>
void VEM_MAR<T>::update_elbo()
{
    
    Rmat xi = lxi.array().exp().matrix();
    MatrixXd psi = lpsi.array().exp().matrix();
    
    double f = ((xi.transpose() * m_y * xi).array() * lpsi.array()).sum() - lfact_y;
    MatrixXd XPX = (xi * psi * xi.transpose());
    XPX.diagonal().setZero();
    f -= XPX.sum();
    f -= (xi.array() * lxi.array()).sum() + (xi * lpi).sum();
    
    m_elbo = f;
    
}



// -------------------------------------------------------------
// E-step
// -------------------------------------------------------------

template<>
void VEM_MAR<MatrixXd>::estep(
        int estep_maxit,
        double estep_tol,
        bool debug
) {
    
    MatrixXd psi = lpsi.array().exp().matrix();
    Rmat xi = lxi.array().exp().matrix();
    
    for (int iter = 0; iter < estep_maxit; ++iter) {
        
        Rcpp::checkUserInterrupt();
        
        Rmat lxi_old = lxi;
        
        for (int i = 0; i < m_nodes; ++i) {
            
            ArrayXd tmparr = ArrayXd::Zero(m_G);

            for (int k = 0; k < m_G; ++k) {
                
                // MatrixXd g_ik = m_y.row(i).transpose() * lpsi.row(k);
                // g_ik.rowwise() -= psi.row(k);
                // g_ik += m_y.col(i) * lpsi.col(k).transpose();
                // g_ik.rowwise() -= psi.col(k).transpose();
                // 
                // tmparr(k) = ( g_ik.array() * lxi.array().exp() ).sum();
                
                MatrixXd g_ik = m_y.row(i).transpose() * lpsi.row(k) + m_y.col(i) * lpsi.col(k).transpose();
                g_ik.rowwise() -= psi.row(k);
                g_ik.rowwise() -= psi.col(k).transpose();
                
                tmparr(k) = ( g_ik.array() * xi.array() ).sum() + xi.row(i) * (psi.row(k).transpose() + psi.col(k));
                
            }
            
            tmparr += lpi.array();
            lxi.row(i) = tmparr - log_sum_exp(tmparr);
            xi.row(i) = lxi.row(i).array().exp().matrix();
            
        }
        
        bool conv = (lxi - lxi_old).cwiseAbs().maxCoeff() < estep_tol;
        
        if (conv) 
            break ;
        
        if ((iter == estep_maxit - 1L) && debug) {
            
            Rcpp::warning("Max-iter reached (E-step)");
            
        }
        
    }
    
    return ;
    
}

template<>
void VEM_MAR<SpMat>::estep(
        int estep_maxit,
        double estep_tol,
        bool debug
) {
    
    Eigen::SparseMatrix<double, Eigen::RowMajor> yr(m_y);
    
    MatrixXd psi = lpsi.array().exp().matrix();
    Rmat xi = lxi.array().exp().matrix();

    for (int iter = 0; iter < estep_maxit; ++iter) {
        
        Rcpp::checkUserInterrupt();
        
        MatrixXd lxi_old = lxi;
        
        for (int i = 0; i < m_nodes; ++i) {
            
            ArrayXd tmparr = ArrayXd::Zero(m_G);
            
            for (int k = 0; k < m_G; ++k) {
                
                // MatrixXd g_ik = yr.row(i).transpose() * lpsi.row(k);
                // g_ik.rowwise() -= psi.row(k);
                // g_ik += m_y.col(i) * lpsi.col(k).transpose();
                // g_ik.rowwise() -= psi.col(k).transpose();
                // 
                // tmparr(k) = ( g_ik.array() * lxi.array().exp() ).sum();
                
                MatrixXd g_ik = yr.row(i).transpose() * lpsi.row(k) + m_y.col(i) * lpsi.col(k).transpose();
                g_ik.rowwise() -= psi.row(k);
                g_ik.rowwise() -= psi.col(k).transpose();
                
                tmparr(k) = ( g_ik.array() * xi.array() ).sum() + xi.row(i) * (psi.row(k).transpose() + psi.col(k));
                
            }
            
            tmparr += lpi.array();
            lxi.row(i) = tmparr - log_sum_exp(tmparr);
            xi.row(i) = lxi.row(i).array().exp().matrix();
            
        }
        
        bool conv = (lxi - lxi_old).cwiseAbs().maxCoeff() < estep_tol;
        
        if (conv) 
            break ;
        
        if ((iter == estep_maxit - 1L) && debug) {
            
            Rcpp::warning("Max-iter reached (E-step)");
            
        }
        
    }
    
    return ;
    
}


// -------------------------------------------------------------
// M-step & Fit
// -------------------------------------------------------------


template <typename T>
void VEM_MAR<T>::mstep() {
    
    MatrixXd xi = lxi.array().exp().matrix();
    
    // update lpi
    for (int k = 0; k < m_G; ++k)
        lpi(k) = log_sum_exp(lxi.col(k));
    lpi.array() -= std::log(m_nodes);
    
#ifdef DEBUG
    Rcpp::Rcout <<  "lpi : " << lpi.transpose() << std::endl;
#endif
    
    // update lpsi 
    // note: xi * m_y * xi works since diagonals of y are set to zero
    RowVectorXd xi_sums = VectorXd::Ones(m_nodes).transpose() * xi;

#ifdef DEBUG
    Rcpp::Rcout <<  "xi_sums : " << xi_sums << std::endl;
#endif
    
    ArrayXXd denom = xi_sums.transpose() * xi_sums - xi.transpose() * xi;
    ArrayXXd numer =  (xi.transpose() * m_y * xi);
    // denom = (denom == 0).select(1, denom);
    
    lpsi = (numer.log() - denom.log() ).matrix();
    lpsi = (denom == 0 || numer == 0).select(0.0, lpsi);
        
#ifdef DEBUG
    Rcpp::Rcout <<  "denom : " << denom << std::endl;
    Rcpp::Rcout <<  "numer : " << (xi.transpose() * m_y * xi) << std::endl;
    Rcpp::Rcout <<  "lpsi : " << lpsi << std::endl;
#endif
    

    return ;
        
}

template <typename T>
void VEM_MAR<T>::fit(
        int maxit,
        double tol,
        int estep_maxit,
        double estep_tol,
        bool debug
){
    
    double elbo_old = get_elbo();
    
    if (m_verbose > 0)
        Rcpp::Rcout <<
        "Initial ELBO: " <<
        std::fixed <<
        std::setprecision(5) <<
        elbo_old <<
        std::endl;
    
    for (m_iter = 0; m_iter < maxit; ++m_iter) {
        
        Rcpp::checkUserInterrupt();
        
        // if first iteration, perform mstep first
        // note: this is necessary, since otherwise lxi might
        //       result in degenerate corner-solutions
        //       (since psi is initialized randomly)
        if (m_iter == 0)
            mstep();
        
        if (m_verbose > 0 && (m_iter % m_verbose == 0))
            Rcpp::Rcout << "VE-step ... " << std::endl;
        
        estep(estep_maxit, estep_tol, debug);
        
#ifdef DEBUG
        Rcpp::Rcout << "lxi : " << lxi << "\n" 
                    << "lpi : " << lpi.transpose() << std::endl;
        
        double elbo_old = m_elbo;
        update_elbo();
        
        if (elbo_old > m_elbo) {
            Rcpp::Rcout << "old elbo: " << elbo_old << std::endl;
            Rcpp::Rcout << "new elbo: " << m_elbo << std::endl;
            Rcpp::stop("elbo decreased at E-step");
        }
        
        elbo_old = m_elbo;
        
#endif
          
        if (m_verbose > 0 && (m_iter % m_verbose == 0))
            Rcpp::Rcout << "VM-step ... " << std::endl;
        
        mstep();
        update_elbo();
        
#ifdef DEBUG
        
        if (elbo_old > m_elbo) {
            Rcpp::Rcout << "old elbo: " << elbo_old << std::endl;
            Rcpp::Rcout << "new elbo: " << m_elbo << std::endl;
            Rcpp::stop("elbo decreased at E-step");
        }
        
#endif
        
        
        m_elbo_hist.push_back(m_elbo);
        
        if (!std::isfinite(m_elbo))
            Rcpp::stop("non-finite elbo value!");
        
        if (m_verbose > 0 && (m_iter % m_verbose == 0))
            Rcpp::Rcout <<
                "Iteration " <<
                m_iter + 1L <<
                " :  ELBO " <<
                std::fixed <<
                std::setprecision(5) <<
                m_elbo <<
                std::endl;
        
        
        if (abs(m_elbo - elbo_old) < tol * abs(elbo_old)) {
            
            if (m_verbose > 0)
                Rcpp::Rcout << "\nVEM converged" << std::endl;
            
            break;
            
        }
        
        
        elbo_old = m_elbo;
        
    }
    
}

// -------------------------------------------------------------
// Misc
// -------------------------------------------------------------

template <typename T>
double VEM_MAR<T>::get_icl(const T& mobmat) const 
{
    
    MatrixXd psi = lpsi.array().exp().matrix();
    
    // get predicted block
    ArrayXi z(m_nodes);
    for (int i = 0; i < m_nodes; ++i)
        lxi.row(i).maxCoeff(&z(i));
    
    
    double ill(0.0);
    for (int j = 0; j < m_nodes; ++j) {
        
        int z_j = z(j);
        VectorXd y_j = mobmat.col(j);
        
        ill += lpi(z_j);
        
        for (int i = 0; i < m_nodes; ++i) {
            
            if (i != j) {
                
                ill += R::dpois(y_j(i), psi(z(i), z_j), true);
                
            } else {
                
                // diagonals are fitted perfectly
                ill += R::dpois(y_j(i), y_j(i), true);
                
            }
            
        }
        
    }
    
    int n_params_Q2 = m_nodes + m_G * m_G;
    int n_params_Q1 = m_G - 1L;
    
    return ill - std::log(m_nodes) * (double)n_params_Q2
        - 0.5 * std::log(m_nodes) * (double)n_params_Q1;
    
    
}

// explicit instantiation
template class VEM_MAR<Eigen::MatrixXd>;
template class VEM_MAR<SpMat>;


// EOF //
