#include <RcppArmadillo.h>
// #define NDEBUG
#include <RcppEigen.h>
#include "LBFGS.h"
// #include "LBFGSB.h"
