library("sbmob")
load("bugfiles/anne/sample-for-spectral-prob.RData")

x = copy(edgelist)

# runs fine
# fit = sbm(edgelist, nblocks = 2, model = "diagonal", sparse = T)
# fit = sbm(edgelist, nblocks = 2, model = "qindep", sparse = T)


# error
fit = sbm(x, nblocks = 2, model = "diagonal", gen_inits="spectral")
# fit = sbm(x, nblocks = 2, model = "qindep")


# helper
init_list_to_lxi = function() {
    
    t(
        log(
            apply(
                init_list$sq_dist, 
                1L, 
                function(w) { 
                    tmp = exp(-w)
                    tmp / sum(tmp)
                }
            )
        )
    )
    
}

con = list(
    maxit = 50,
    tol = 1e-07,
    estep_maxit = 30,
    estep_tol = 1e-07,
    mstep_m = 6,
    mstep_epsilon = 1e-07,
    mstep_past = 1,
    mstep_delta = 1e-07,
    mstep_maxit = 100,
    mstep_maxlinesearch = 30,
    stable_density_calc = FALSE,
    debug = FALSE
)

gen_inits = "spectral"
spectral_type = "bib_norm"

# error
init_list = sbmob::create_inits_spectral(
    x, 2, 2, FALSE, 1, TRUE, TRUE
)

x_mat = as.matrix(x)
res = sbmob:::.get_inits_spectral(x_mat, 2, 1, FALSE, 2, TRUE, TRUE)
x_mat2 = x_mat
x_mat2 = x_mat2[x_mat2[, 1] != x_mat2[, 2], ]
res2 = sbmob:::.get_inits_spectral(x_mat2, 2, 1, FALSE, 2, TRUE, TRUE)
x_mat3 = x_mat
x_mat3[x_mat3[, 1] == x_mat3[, 2], ] = 0
res = sbmob:::.get_inits_spectral(x_mat3, 2, 1, FALSE, 2, TRUE, TRUE)

comp_list = get_components(x_mat, T)
comp_list = cbind(seq_along(comp_list) - 1L, comp_list)
lcomp = comp_list[comp_list[, 2] == 18, 1L]

x_mat = x_mat[x_mat[, 1] %in% lcomp & x_mat[, 2] %in% lcomp, ]
y = cbind(match(x_mat[, 1], lcomp) - 1L, match(x_mat[, 2], lcomp) - 1L, x_mat[,3])


res = sbmob:::.get_inits_spectral(y, 2, 1, FALSE, 2, TRUE, TRUE)
y2 = y
y2 = y2[y2[, 1] != y2[, 2], ]
res2 = sbmob:::.get_inits_spectral(y2, 2, 1, FALSE, 2, TRUE, TRUE)
y3 = y
y3[y3[, 1] == y3[, 2], ] = 0
res = sbmob:::.get_inits_spectral(y3, 2, 1, FALSE, 2, TRUE, TRUE)



# get_fit = function(el, type = "default") {
#     
#     fit = sbmob::sbm(x = el, nblocks = 2L, model = "diagonal",
#                       gen_inits = 'spectral', spectral_type = type,
#                       verbose = FALSE)
#     
#     return(fit)
# }
# 
# 
# spectral_types = c("default", "dc", "dc_norm", "bib", "bib_norm", "simple",
#                     "simple_norm")
# 
# for (type in spectral_types) {
#     tryCatch (
#         get_fit(e, type),
#         error = function(e) {
#             message(paste("error:", type, e))
#         }
#     )
# }