#ifndef KMEANS_H
#define KMEANS_H

#include <RcppArmadillo.h>
using namespace Rcpp;

inline Rcpp::List run_kmeans(
    const arma::mat& eigvec,
    arma::uword N,
    arma::uword G,
    arma::uword verbose
) {
    
    arma::mat centroids;
    arma::uvec cluster(N);
    arma::mat dist_mat(N, G);
    
    if (eigvec.n_cols != N)
        Rcpp::stop("Dimension mismatch in run_kmeans");
    
    bool ecode = arma::kmeans(centroids, eigvec, G, arma::static_spread, 10, false);
    
    if (ecode) {
        
        if (verbose > 0) 
            Rcpp::Rcout << "K-means converged" << std::endl;
        
    } else {
        
        Rcpp::stop("K-means failed");
        
    }
    
    for (arma::uword i = 0; i < N; ++i) {
        
        arma::vec eig_i = eigvec.col(i);
        arma::rowvec dist(G);
        
        for (arma::uword j = 0; j < G; ++j) 
            dist(j) = arma::norm(eig_i - centroids.col(j));
        
        cluster(i) = arma::index_min(dist);
        dist_mat.row(i) = dist;
        
    }

    return Rcpp::List::create(centroids, eigvec.t(), cluster, dist_mat, ecode);
    
}
    
#endif
