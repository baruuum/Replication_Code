#ifndef BLOCKCOMPARE_H
#define BLOCKCOMPARE_H

#include <Rcpp.h>
#include "utils/expsums.h"

template <typename T>
inline double entropy(const T & x) {
    
    using std::log;
    
    double ent(0.0);
    double N = std::accumulate(x.begin(), x.end(), 0.0);
    double log_N = log(N);
    
    typename T::const_iterator i;
    
    for (i = x.begin(); i != x.end(); ++i)
        if (*i > 0)
            ent += *i * (log(*i) - log_N);
        
    return -1.0 * ent / N;
        
};

Rcpp::IntegerMatrix crosstab(
    const Rcpp::IntegerVector& x,
    const Rcpp::IntegerVector& y
);

double rand_indx(
        const Rcpp::IntegerVector& x,
        const Rcpp::IntegerVector& y,
        bool adjust = false
);

double nmi(
    const Rcpp::IntegerVector& x,
    const Rcpp::IntegerVector& y,
    int norm = 0
);


#endif
