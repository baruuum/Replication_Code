#ifndef MATRIX_LFACTORIAL_H
#define MATRIX_LFACTORIAL_H

//' Sum the log-factorial values of matrix elements
//' 
//' @param T matrix, either Eigen::MatrixXd or Eigen::SparseMatrix<double>
//' @return returns the sum of the log-factorials of matrix entries

// specialized template, VectorXd
inline double matrix_lfactorial(const Eigen::VectorXd& y) {
    
    double lfact(0.0);
    for (int i = 0; i < y.size(); ++i)
        if (y(i) >= 2)
            lfact += R::lgammafn(y(i) + 1.0);
        
    return lfact;
            
}

// specialized template, MatrixXd
inline double matrix_lfactorial(const Eigen::MatrixXd& y) {
    
    double lfact(0.0);
    for (int j = 0; j < y.cols(); ++j)
        for (int i = 0; i < y.rows(); ++i)
            if (y(i, j) >= 2)
                lfact += R::lgammafn(y(i, j) + 1.0);
            
    return lfact;
            
}

// specialized template, SparseMatrix<double>
inline double matrix_lfactorial(const Eigen::SparseMatrix<double>& y) {
    
    double lfact(0.0);
    for (int j = 0; j < y.outerSize(); ++j)
        for (Eigen::SparseMatrix<double>::InnerIterator it(y, j); it; ++it)
            if (it.value() >= 2)
                lfact += R::lgammafn(it.value() + 1.0);
            
    return lfact;
        
}

#endif
