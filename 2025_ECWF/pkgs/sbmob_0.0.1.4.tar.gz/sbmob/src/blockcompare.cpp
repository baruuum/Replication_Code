#include "blockcompare.h"

using namespace Rcpp;

// Cross table -----------------------------------------------------------------

//' Crosstable of two integervectors (not exported)
//'
//' @param x,y integer vectors
//' @return returns the crosstable of \code{x} and \code{y}
IntegerMatrix crosstab(const IntegerVector& x, const IntegerVector& y) {

    if (x.size() != y.size())
        stop("Dimension mismatch between x and y");

    IntegerVector ux = sort_unique(x);
    IntegerVector uy = sort_unique(y);
    IntegerVector lx = match(x, ux) - 1L;
    IntegerVector ly = match(y, uy) - 1L;

    IntegerMatrix m(ux.size(), uy.size());

    for (int i = 0; i < x.size(); ++i)
        ++m(lx[i], ly[i]);

    return m;

}

// Rand indx -------------------------------------------------------------------

//' Rand and adjusted-Rand index
//'
//' @param x,y non-negative integer vectors of the same length
//' @param adjust boolean; if \code{TRUE}, returns the adjusted index
//' @return returns the Rand or adjusted-Rand index between two integer vectors
//' @export
//[[Rcpp::export]]
double rand_indx(
        const IntegerVector& x,
        const IntegerVector& y,
        bool adjust
) {

    using std::log;
    using std::exp;

    int N = x.size();

    if (y.size() != N)
        stop("Dimension mismatch between x and y");

    if (is_true(any(x < 0)) || is_true(any(y < 0)))
        stop("x and y have to be non-negative");

    if ( is_true(any(is_na(x))) || is_true(any(is_na(y))) )
        stop("x and y have to be non-negative");

    if (unique(x).size() == 1 && unique(y).size() == 1)
        return 1.0;

    if (adjust) {

        if (unique(x).size() == 1 || unique(y).size() == 1)
            return 0.0;

        IntegerMatrix m = crosstab(x, y);

        NumericVector lfr(rowSums(m));
        NumericVector lfc(colSums(m));
        NumericVector lfm(m);

        for (NumericVector::iterator i = lfr.begin(); i != lfr.end(); ++i)
            *i = R::lchoose(*i, 2L);

        for (NumericVector::iterator i = lfc.begin(); i != lfc.end(); ++i)
            *i = R::lchoose(*i, 2L);

        for (NumericVector::iterator i = lfm.begin(); i != lfm.end(); ++i)
            *i = R::lchoose(*i, 2L);

        double lfr_sum = log_sum_exp_rcpp_nv(lfr);
        double lfc_sum = log_sum_exp_rcpp_nv(lfc);
        double lfm_sum = log_sum_exp_rcpp_nv(lfm);

        double lexpected = lfr_sum + lfc_sum - R::lchoose(N, 2L);
        double lmax = log(0.5) + log_add_exp(lfr_sum, lfc_sum);

        double ldenom = log_diff_exp(lmax, lexpected);

        if (lfm_sum > lexpected)
            return exp(log_diff_exp(lfm_sum, lexpected) - ldenom);

        return ( exp(lfm_sum) - exp(lexpected) ) / exp(ldenom);

    }

    // unadjusted rand index
    int n_disag(0L);

    for (int i = 0; i < N; ++i) {
        for (int j = i + 1L; j < N; ++j) {

            int s1 = x[i] == x[j] ? 0 : 1;
            int s2 = y[i] == y[j] ? 0 : 1;

            if (s1 != s2)
                ++n_disag;

        }

    }

    double r = log(n_disag) - R::lchoose(N, 2.);
    return 1.0 - exp(r);

}


// Normalized Mutual Information, sqrt -----------------------------------------

//' Normalized Mutual Information
//'
//' @param x,y non-negative integer vectors of the same length
//' @param norm integer, chooses the way of normalizing the mutual information (0 for geometric mean, 1 for arithmetic mean, and otherwise the harmonic mean of the entropies)
//' @return returns the normalized mutual information (NMI) between two integervectors
//' @details The normalized mutual information between vectors \code{x} and \code{y} are calculated as \code{M(x, y) / sqrt(H(x) * H(y))}, where \code{M} is the mutual information between \code{x} and \code{y}, and \code{H(x), H(y)} are their respective entropies.
//' @export
//[[Rcpp::export]]
double nmi(const IntegerVector& x, const IntegerVector& y, int norm)
{

    if (y.size() != x.size())
        stop("Dimension mismatch between x and y");

    if (is_true(any(x < 0)) || is_true(any(y < 0)))
        stop("x and y have to be non-negative");

    if ( is_true(any(is_na(x))) || is_true(any(is_na(y))) )
        stop("x and y have to be non-negative");


    IntegerMatrix m = crosstab(x, y);
    const int I = m.rows();
    const int J = m.cols();

    const double N = sum(m);
    const NumericVector rs(rowSums(m));
    const NumericVector cs(colSums(m));

    double ers = entropy(rs);
    double ecs = entropy(cs);

    if (ers == 0 || ecs == 0)
        return 0.0;

    const NumericVector log_r = log(rs);
    const NumericVector log_c = log(cs);

    double mi(0.0);
    for (int j = 0; j < J; ++j)
        for (int i = 0; i < I; ++i)
            if (m(i, j) > 0)
                mi += m(i,j) * (std::log(m(i,j)) - log_r(i) - log_c(j));

    mi /= N;
    mi += std::log(N);

    if (norm == 0) {

        return mi / sqrt(ers * ecs);

    } else if (norm == 1) {

        return 2.0 * mi / (ers + ecs);

    } else {

        return 0.5 * mi * (ers + ecs) / (ers * ecs);

    }

    return 0.0;

}

// EOF //
