//[[Rcpp::depends(RcppEigen)]]
#include <RcppEigen.h>

#ifdef _OpenMP
    #include <omp.h>
    // [[Rcpp::plugins(openmp)]]
#endif

#include "VEM.h"
#include "VEM_MAR.h"

// -------------------------------------------------------------
// VEM (with diagonal, row, and column effects)
// -------------------------------------------------------------

//' Export VEM function
//'
//' @param y mobility matrix
//' @param lxi initial guess of block membership probabilities
//' @param n_threads number of threads to use
//' @param verbose if greater than 0 prints output
//' @param controls list of control parameters
//' @export
//[[Rcpp::export(.fit_vem)]]
Rcpp::List R_vem_export(
        const Eigen::MatrixXd& y,
        const Eigen::MatrixXd& lxi,
        int n_threads,
        int verbose,
        const Rcpp::List& controls
){
    
    Eigen::setNbThreads(n_threads);
    
    VEM<Eigen::MatrixXd> mod(y, lxi, verbose);

    mod.fit(
        controls["maxit"],
        controls["tol"],
        controls["estep_maxit"],
        controls["estep_tol"],
        controls["mstep_m"],
        controls["mstep_epsilon"],
        controls["mstep_past"],
        controls["mstep_delta"],
        controls["mstep_maxit"],
        controls["mstep_maxlinesearch"],
        controls["stable_density_calc"],
        controls["debug"]
    );

    return Rcpp::List::create(
        Rcpp::_["elbo"]      = mod.get_elbo(),
        Rcpp::_["lalpha"]    = mod.get_lalpha(),
        Rcpp::_["lbeta"]     = mod.get_lbeta(),
        Rcpp::_["lpsi"]      = mod.get_lpsi(),
        Rcpp::_["lpi"]       = mod.get_lpi(),
        Rcpp::_["lxi"]       = mod.get_lxi(),
        Rcpp::_["elbo_hist"] = mod.get_elbo_hist(),
        Rcpp::_["ICL"]       = mod.get_icl(y)
    );

}


//' Export VEM function (sparse matrices)
//'
//' @param y mobility matrix
//' @param lxi initial guess of block membership probabilities
//' @param n_threads number of threads to use
//' @param verbose if greater than 0 prints output
//' @param controls list of control parameters
//' @export
//[[Rcpp::export(.fit_vem_sparse)]]
Rcpp::List R_vem_export_sparse(
        const Eigen::SparseMatrix<double>& y,
        const Eigen::MatrixXd& lxi,
        int n_threads,
        int verbose,
        const Rcpp::List& controls
){
    
    Eigen::setNbThreads(n_threads);

    VEM<Eigen::SparseMatrix<double>> mod(y, lxi, verbose);

    mod.fit(
        controls["maxit"],
        controls["tol"],
        controls["estep_maxit"],
        controls["estep_tol"],
        controls["mstep_m"],
        controls["mstep_epsilon"],
        controls["mstep_past"],
        controls["mstep_delta"],
        controls["mstep_maxit"],
        controls["mstep_maxlinesearch"],
        controls["debug"]
    );

    return Rcpp::List::create(
        Rcpp::_["elbo"]      = mod.get_elbo(),
        Rcpp::_["lalpha"]    = mod.get_lalpha(),
        Rcpp::_["lbeta"]     = mod.get_lbeta(),
        Rcpp::_["lpsi"]      = mod.get_lpsi(),
        Rcpp::_["lpi"]       = mod.get_lpi(),
        Rcpp::_["lxi"]       = mod.get_lxi(),
        Rcpp::_["elbo_hist"] = mod.get_elbo_hist(),
        Rcpp::_["ICL"]       = mod.get_icl(y)
    );
    
}


// -------------------------------------------------------------
// VEM (with only diagonal effects)
// -------------------------------------------------------------

//' Export VEM_MAR function
//'
//' @param y mobility matrix
//' @param lxi initial guess of block membership probabilities
//' @param n_threads number of threads to use
//' @param verbose if greater than 0 prints output
//' @param controls list of control parameters
//' @export
//[[Rcpp::export(.fit_vem_mar)]]
Rcpp::List R_vem_mar_export(
        const Eigen::MatrixXd& y,
        const Eigen::MatrixXd& lxi,
        int n_threads,
        int verbose,
        const Rcpp::List& controls
){
    
    Eigen::setNbThreads(n_threads);
    
    VEM_MAR<MatrixXd> mod(y, lxi, verbose);
    
    mod.fit(
        controls["maxit"],
        controls["tol"],
        controls["estep_maxit"],
        controls["estep_tol"],
        controls["debug"]
    );
    
    return Rcpp::List::create(
        Rcpp::_["elbo"]      = mod.get_elbo(),
        Rcpp::_["lalpha"]    = NA_REAL,
        Rcpp::_["lbeta"]     = NA_REAL,
        Rcpp::_["lpsi"]      = mod.get_lpsi(),
        Rcpp::_["lpi"]       = mod.get_lpi(),
        Rcpp::_["lxi"]       = mod.get_lxi(),
        Rcpp::_["elbo_hist"] = mod.get_elbo_hist(),
        Rcpp::_["ICL"]       = mod.get_icl(y)
    );
    
}


//' Export VEM_MAR function (sparse matrices)
//'
//' @param y mobility matrix
//' @param lxi initial guess of block membership probabilities
//' @param n_threads number of threads to use
//' @param verbose if greater than 0 prints output
//' @param controls list of control parameters
//' @export
//[[Rcpp::export(.fit_vem_mar_sparse)]]
Rcpp::List R_vem_mar_export_sparse(
        const Eigen::SparseMatrix<double>& y,
        const Eigen::MatrixXd& lxi,
        int n_threads,
        int verbose,
        const Rcpp::List& controls
){
    
    Eigen::setNbThreads(n_threads);

    VEM_MAR<Eigen::SparseMatrix<double>> mod(y, lxi, verbose);
    
    mod.fit(
        controls["maxit"],
        controls["tol"],
        controls["estep_maxit"],
        controls["estep_tol"],
        controls["debug"]
    );
    
    return Rcpp::List::create(
        Rcpp::_["elbo"]      = mod.get_elbo(),
        Rcpp::_["lalpha"]    = NA_REAL,
        Rcpp::_["lbeta"]     = NA_REAL,
        Rcpp::_["lpsi"]      = mod.get_lpsi(),
        Rcpp::_["lpi"]       = mod.get_lpi(),
        Rcpp::_["lxi"]       = mod.get_lxi(),
        Rcpp::_["elbo_hist"] = mod.get_elbo_hist(),
        Rcpp::_["ICL"]       = mod.get_icl(y)
    );
    
}

// EOF //
