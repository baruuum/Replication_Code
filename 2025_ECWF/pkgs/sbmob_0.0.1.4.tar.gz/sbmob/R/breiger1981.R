#' Featherman-Hauser Mobility Table and Breiger's H7 Partition
#'
#' A dataset containing the mobility table analyzed in Breiger (1981) together with
#' the partition according to hypothesis H7
#'
#' @format A \code{list} object of length 2
#' \describe{
#'     \item{mobmat}{a \code{matrix}; the mobility table}
#'     \item{H7}{an \code{integer} vector; The partition of hypothesis H7}
#' }
#' @usage data(breiger1981)
#' @source Ronald L. Breiger. 1981. "The Social Class Structure of Occupational Mobility," American Journal of Sociology, Vol. 87, No. 3, pp. 578-611. Table appears on page 592.
"breiger1981"