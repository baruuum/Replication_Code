#include <RcppArmadillo.h>
#include "utils/dfs.h"
//[[Rcpp::depends(RcppArmadillo)]]

//' Components of network
//'
//' Determines the components of a graph from a (possibly weighted) edgelist using depth-first search
//'
//' @param elist a unsigned integer matrix with 3 columns: (1) sender, (2) receiver, (3) weights
//' @param N dimension of matrix
//' @param min_indx minimum index of edgelist
//' @returns a integer vector with component membership of each node
//' @details indices of the component vector starts from 1 and not 0
//[[Rcpp::export(.get_components)]]
arma::uvec get_components(
    const arma::umat& elist,
    arma::uword N,
    arma::uword min_indx
) {
    
    if (elist.n_cols != 3)
        Rcpp::stop("input has to be an edgelist with 3 columns");
    
    if (min_indx < 0 || min_indx > 2)
        Rcpp::stop("minimum index in elist has to be either 0 or 1");
    
    // construct sparse matrix (unsigned integer)
    arma::sp_umat x(elist.cols(0, 1).t() - min_indx, elist.col(2), N, N);
    x = x + x.t();
    
    arma::uvec res(N, arma::fill::zeros);
    arma::uword comp(0L);
    
    for (arma::uword i = 0; i < N; ++i) {
        
        if (!res(i)) {
            
            comp += 1L;
            dfs_arma_sp(i, comp, res, x);
            
        }
        
    }
    
    return res;
    
}

// //' Check whether graph is connected
// //'
// //' @param elist a unsigned integer matrix with 3 columns: (1) sender, (2) receiver, (3) weights
// //' @param verbose boolean whether to print out intermediate information
// //' @returns \code{true} if graph is connected, \code{false} otherwise
// //[[Rcpp::export(.is_connected)]]
// bool is_connected(
//         const arma::umat& elist,
//         bool verbose = true
// )
// {
//     if (elist.n_cols != 3)
//         Rcpp::stop("input has to be an edgelist with 3 columns");
//     
//     arma::uword min_indx = elist.cols(0, 1).min();
// 
//     if (min_indx < 0 || min_indx > 2)
//         Rcpp::stop("minimum index in elist has to be either 0 or 1");
// 
//     arma::uword N = elist.cols(0, 1).max() + 1L - min_indx;
//         
//     // construct sparse matrix (unsigned integer)
//     arma::sp_umat x(elist.cols(0, 1).t() - min_indx, elist.col(2), N, N);
//     x = x + x.t();
//     
//     arma::uvec res(N, arma::fill::zeros);
//     arma::uword comp(0L);
//     
//     if (verbose)
//         Rcpp::Rcout << "Matrix has " << N << " rows/columns";
//     
//     for (arma::uword i = 0; i < N; ++i) {
//         
//         if (!res(i)) {
//             
//             comp += 1L;
//             dfs_arma_sp(i, comp, res, x);
//             
//         }
//         
//         if (comp > 1L)
//             return false;
//         
//     }
//     
//     return true;
//     
// }
// 
