#' sbmob: stochastic blockmodels for mobility tables
#'
#' Package to fit stochastic blockmodels to mobility data using stochastic EM and variational EM methods
#' 
#' @docType package
#' @name sbmob
#' @useDynLib sbmob, .registration = TRUE
#' @importFrom data.table data.table setnames setkey setcolorder setDT copy melt as.data.table dcast .N `:=`
#' @importFrom Rcpp sourceCpp
#' @importFrom stats rpois dpois poisson as.formula glm pchisq coef runif logLik
NULL
