//[[Rcpp::depends(RcppEigen)]]
#include "VEM.h"


// -------------------------------------------------------------
// Constructors
// -------------------------------------------------------------

template <typename T>
VEM<T>::VEM(
    const T& mobmat,     
    const MatrixXd& lxi_inits,
    int verbose
) : VBase<T>::VBase(mobmat, lxi_inits),
    lalpha(m_nodes - 1L),
    lbeta(m_nodes - 1L),
    m_iter(0L),
    m_verbose(verbose)
{
    
    // for (int i = 0; i < (m_nodes - 1L); ++i) {
    //     
    //     lalpha(i) = R::rnorm(0.0, 1.0);
    //     lbeta(i)  = R::rnorm(0.0, 1.0);
    //     
    // }
    lalpha.setZero();
    lbeta.setZero();
    
    mstep(6, 1e-05, 1, 1e-05, 300, 50, false);
    m_elbo_hist.push_back(get_elbo());

}

template <typename T>
VEM<T>::VEM(
    const T& mobmat,
    const MatrixXd& lxi_inits,
    const VectorXd& lalpha_inits,
    const VectorXd& lbeta_inits,
    const MatrixXd& lpsi_inits,
    const VectorXd& lpi_inits,
    int verbose
) : VBase<T>::VBase(mobmat, lxi_inits, lpsi_inits, lpi_inits),
    lalpha(lalpha_inits),
    lbeta(lbeta_inits),
    m_iter(0L), 
    m_verbose(verbose)
{
    
    // check args
    if (lalpha.size() != m_nodes - 1L)
        Rcpp::stop("size mismatch in lalpha inits");
    
    if (lbeta.size() != m_nodes - 1L)
        Rcpp::stop("size mismatch in lbeta inits");
    
    // updating elbo based on current pars
    Rmat xi = lxi.array().exp().matrix();
    double lfact_y = matrix_lfactorial(m_y);
    
    m_elbo = -1.0 * wpois::elbo_theta(m_y, lxi, lalpha.array(), lbeta.array(), lpsi, lfact_y, true) - 
        (xi.array() * lxi.array()).sum() + 
        (xi * lpi).sum();
    
    m_elbo_hist.push_back(get_elbo());
    
}


// -------------------------------------------------------------
// E-step
// -------------------------------------------------------------

template <>
void VEM<MatrixXd>::estep(
        int estep_maxit,
        double estep_tol,
        bool debug
) {
    
    MatrixXd psi = lpsi.array().exp().matrix();
    Rmat xi = lxi.array().exp().matrix();
    
    for (int iter = 0; iter < estep_maxit; ++iter) {
        
        Rcpp::checkUserInterrupt();
        
        MatrixXd lxi_old = lxi;
        
        for (int i = 0; i < m_nodes; ++i) {
            
            ArrayXd tmparr = ArrayXd::Zero(m_G);
            VectorXd mu_row_i(m_nodes), mu_col_i(m_nodes);
            
            // ith row of mu (alpha * beta^T) with diagonals set to zero
            mu_row_i << 1.0, lbeta.array().exp().matrix();
            mu_row_i *= (i == 0) ? 1.0 : std::exp(lalpha(i - 1L));
            mu_row_i(i) = 0.0;
            
            // ith col of mu (alpha * beta^T) with diagonals set to zero
            mu_col_i << 1.0, lalpha.array().exp().matrix();
            mu_col_i *= (i == 0) ? 1.0 : std::exp(lbeta(i - 1L));
            mu_col_i(i) = 0.0;
            
            for (int k = 0; k < m_G; ++k) {
                
                MatrixXd g_ik = m_y.row(i).transpose() * lpsi.row(k) -
                    mu_row_i * psi.row(k) +
                    m_y.col(i) * lpsi.col(k).transpose() -
                    mu_col_i * psi.col(k).transpose();
                
                tmparr(k) = (g_ik.array() * xi.array()).sum();
                
            }
            
            tmparr += lpi.array();
            lxi.row(i) = tmparr - log_sum_exp(tmparr);
            xi.row(i) = lxi.row(i).array().exp().matrix();
            
        }
        
        bool conv = (lxi - lxi_old).cwiseAbs().maxCoeff() < estep_tol;
        
        if (conv) 
            break ;
        
        if ((iter == estep_maxit - 1L) && debug) {
            
            Rcpp::String s("Max-iter reached (E-step)");
            // s += " at iteration " + std::to_string(m_iter);
            
            Rcpp::warning(s);
            
        }
        
    }
    
    return ;
    
}

template <>
void VEM<SpMat>::estep(
        int estep_maxit,
        double estep_tol,
        bool debug
) {
    
    Eigen::SparseMatrix<double, Eigen::RowMajor> yr(m_y);
    
    MatrixXd psi = lpsi.array().exp().matrix();
    Rmat xi = lxi.array().exp().matrix();
    
    for (int iter = 0; iter < estep_maxit; ++iter) {
        
        Rcpp::checkUserInterrupt();
        
        MatrixXd lxi_old = lxi;
        
        for (int i = 0; i < m_nodes; ++i) {
            
            ArrayXd tmparr = ArrayXd::Zero(m_G);
            VectorXd mu_row_i(m_nodes), mu_col_i(m_nodes);
            
            // ith row of mu (alpha * beta^T) with diagonals set to zero
            mu_row_i << 1.0, lbeta.array().exp().matrix();
            mu_row_i *= (i == 0) ? 1.0 : std::exp(lalpha(i - 1L));
            mu_row_i(i) = 0.0;
            
            // ith col of mu (alpha * beta^T) with diagonals set to zero
            mu_col_i << 1.0, lalpha.array().exp().matrix();
            mu_col_i *= (i == 0) ? 1.0 : std::exp(lbeta(i - 1L));
            mu_col_i(i) = 0.0;
            
            for (int k = 0; k < m_G; ++k) {
                
                MatrixXd g_ik = yr.row(i).transpose() * lpsi.row(k) -
                    mu_row_i * psi.row(k) +
                    m_y.col(i) * lpsi.col(k).transpose() -
                    mu_col_i * psi.col(k).transpose();
                
                tmparr(k) = (g_ik.array() * xi.array()).sum();
                
            }
            
            tmparr += lpi.array();
            lxi.row(i) = tmparr - log_sum_exp(tmparr);
            xi.row(i) = lxi.row(i).array().exp().matrix();
            
        }
        
        bool conv = (lxi - lxi_old).cwiseAbs().maxCoeff() < estep_tol;
        
        if (conv) 
            break ;
        
        if ((iter == estep_maxit - 1L) && debug) {
            
            Rcpp::String s("Max-iter reached (E-step)");
            // s += " at iteration " + std::to_string(m_iter);
            
            Rcpp::warning(s);
            
        }
        
    }
    
    return ;
    
}

// -------------------------------------------------------------
// M-step & Fit
// -------------------------------------------------------------

template <typename T>
void VEM<T>::mstep(
    int mstep_m,
    double mstep_epsilon,
    int mstep_past,
    double mstep_delta,
    int mstep_maxit,
    int mstep_maxlinesearch,
    bool stable,
    bool debug
) {

    // L-BFGS algorithm params
    LBFGSpp::LBFGSParam<double> param;
    param.m = mstep_m;
    param.epsilon = mstep_epsilon;
    param.past = mstep_past;
    param.delta = mstep_delta;
    param.max_iterations = mstep_maxit;
    param.max_linesearch = mstep_maxlinesearch;
    // param.linesearch = LBFGSpp::LBFGS_LINESEARCH_BACKTRACKING_STRONG_WOLFE;
    // param.max_linesearch = 50;
    // param.min_step = 1e-20;
    // param.max_step = 1e+20;
    // param.ftol = 1e-04;
    // param.wolfe = 0.9;

    // initialize solver
    LBFGSpp::LBFGSSolver<double, LBFGSpp::LineSearchBacktracking> lbfgs_solver(param);
    // LBFGSpp::LBFGSSolver<double, LBFGSpp::LineSearchNocedalWright> lbfgs_solver(param);
    
    // negative elbo (wrt alpha, beta, and psi)
    double nelbo_theta;

    // pars to optimize
    VectorXd parvec(2L * (m_nodes - 1L) + m_G * m_G);
    parvec << lalpha, lbeta, lpsi.reshaped();

    // minimize elbo (wrt to alpha, beta, and psi)
    wpois::WPoisLL<T> nll(m_y, lxi, stable);

    // Rcpp::Rcout << "optimizing ..." << std::endl;
    int conv = lbfgs_solver.minimize(nll, parvec, nelbo_theta);

    if (conv < 0 && debug) {

        Rcpp::String s("L-BFGS algorithm did not converge (M-step)");
        s += " at iteration " + std::to_string(m_iter);

        Rcpp::warning(s);

    }

    if (conv == mstep_maxit && debug) {

        Rcpp::String s("Max-iter reached (M-step)");
        s += " at iteration " + std::to_string(m_iter);

        Rcpp::warning(s);

    }

    // update params
    // Rcpp::Rcout << "Updating parameters ..." << std::endl;
    // Rcpp::Rcout << "alpha ..." << std::endl;
    lalpha << parvec.segment(0L, m_nodes - 1L);
    // Rcpp::Rcout << "beta ..." << std::endl;
    lbeta  << parvec.segment(m_nodes - 1L, m_nodes - 1L);
    // Rcpp::Rcout << "psi ..." << std::endl;
    lpsi   << parvec.segment(2 * (m_nodes - 1L), m_G * m_G).reshaped(m_G, m_G);

    // update lpi
    for (int k = 0; k < m_G; ++k)
        lpi(k) = log_sum_exp(lxi.col(k));
    lpi.array() -= std::log(m_nodes);

    // update elbo
    m_elbo = -1.0 * nelbo_theta
        + (lxi.array().exp().matrix() * lpi).sum()
        - (lxi.array().exp() * lxi.array()).sum();

    return ;

}


template <typename T>
void VEM<T>::fit(
    int maxit,
    double tol,
    int estep_maxit,
    double estep_tol,
    int mstep_m,
    double mstep_epsilon,
    int mstep_past,
    double mstep_delta,
    int mstep_maxit,
    int mstep_maxlinesearch,
    bool stable,
    bool debug
){

    double elbo_old = get_elbo();

    if (m_verbose > 0)
        Rcpp::Rcout <<
            "Initial ELBO: " <<
            std::fixed <<
            std::setprecision(5) <<
            elbo_old <<
            std::endl;

    for (m_iter = 0; m_iter < maxit; ++m_iter) {

        Rcpp::checkUserInterrupt();

        if (m_verbose > 0 && (m_iter % m_verbose == 0))
            Rcpp::Rcout << "VE-step ... " << std::endl;

        estep(estep_maxit, estep_tol, debug);

        if (m_verbose > 0 && (m_iter % m_verbose == 0))
            Rcpp::Rcout << "VM-step ... " << std::endl;

        mstep(mstep_m, mstep_epsilon, mstep_past, mstep_delta, mstep_maxit, mstep_maxlinesearch, stable, debug);
        m_elbo_hist.push_back(m_elbo);

        if (m_verbose > 0 && (m_iter % m_verbose == 0))
            Rcpp::Rcout <<
                "Iteration " <<
                m_iter + 1L <<
                " :  ELBO " <<
                std::fixed <<
                std::setprecision(5) <<
                m_elbo <<
                std::endl;


        if (abs(m_elbo - elbo_old) < tol * abs(elbo_old)) {

            if (m_verbose > 0)
                Rcpp::Rcout << "\nVEM converged" << std::endl;

            break;

        }

        elbo_old = m_elbo;

    }

}

// -------------------------------------------------------------
// Misc
// -------------------------------------------------------------

template <typename T>
double VEM<T>::get_icl(const T& mobmat) const {
    
    Eigen::VectorXd lalpha_full(m_nodes), lbeta_full(m_nodes);
    lalpha_full << 0.0, lalpha;
    lbeta_full << 0.0, lbeta;
    
    // get predicted block
    Eigen::ArrayXi z(m_nodes);
    for (int i = 0; i < m_nodes; ++i)
        lxi.row(i).maxCoeff(&z(i));
    
    double ill(0.0);
    for (int j = 0; j < m_nodes; ++j) {
        
        int z_j = z(j);
        VectorXd y_j = mobmat.col(j);
        
        ill += lpi(z_j);
        
        for (int i = 0; i < m_nodes; ++i) {
            
            if (i != j) {
                
                ill += R::dpois(
                    y_j(i),
                    std::exp(lalpha_full(i) + lbeta_full(j) + lpsi(z(i), z_j)),
                    true
                );
                
            } else {
                
                // diagonals are fitted perfectly
                ill += R::dpois(y_j(i), y_j(i), true);
                
            }
            
        }
        
    }
    
    int n_params_Q2 = 2L * (m_nodes - 1L) + m_nodes + m_G * m_G;
    int n_params_Q1 = m_G - 1L;
    
    return ill - std::log(m_nodes) * (double)n_params_Q2
        - 0.5 * std::log(m_nodes) * (double)n_params_Q1;
    
    
}
// explicit instantiation
template class wpois::WPoisLL<Eigen::MatrixXd>;
template class wpois::WPoisLL<Eigen::SparseMatrix<double>>;

template class VEM<Eigen::MatrixXd>;
template class VEM<Eigen::SparseMatrix<double>>;

// EOF //
