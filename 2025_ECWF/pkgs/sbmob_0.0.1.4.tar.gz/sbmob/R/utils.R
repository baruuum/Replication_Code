#' get image matrix
#'
#' @param res a \code{sbmob-sbm} object
#' @param log whether to return the (element-wise) logarithm of the image matrix. Defaults to \code{TRUE}
#' @return returns the image matrix
#' @export
image = function(res, log = TRUE) {

    stopifnot(inherits(res, "sbmob-sbm"))

    x = res$lpsi + res$lmu

    if (!log)
        x = exp(x)

    colnames(x) = rownames(x) = seq_len(NROW(x))

    return(x)

}

#' get blocks
#'
#' @param res a \code{sbmob-sbm} object
#' @param as.data.table whether to return a \code{data.table} containing, in addition to the block memebships, the row-index and node names. Defaults to \code{TRUE}.
#' @return returns a vector containing the block memebership of each node
#' @export
blocks = function(res, as.data.table = TRUE) {

    stopifnot(inherits(res, "sbmob-sbm"))

    z = res$post_z

    if (as.data.table)
        z = cbind(res$node_names, block = z)

    return(z)

}

#' get posterior probs
#'
#' @param res a \code{sbmob-sbm} object
#' @param log whether to return the (element-wise) logarithm of the posterior block-probabilities. Defaults to \code{TRUE}
#' @return returns the posterior probabilities with which each node belongs to each block
#' @export
posterior = function(res, log = TRUE) {

    stopifnot(inherits(res, "sbmob-sbm"))
    x = res$lxi

    if (!log)
        x = exp(x)

    rownames(x) = res$node_names$name
    colnames(x) = seq_len(ncol(x))

    return(x)

}

### EOF ###