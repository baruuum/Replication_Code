library("sbmob")

if (requireNamespace("igraph", quietly = TRUE)) {

    for (run in 1:20) {

        n = rpois(1L, 15L)
        k = rpois(1L, 2L)
        p = runif(1, .1, .4)

        g = igraph::sample_gnp(n, p)

        if (k > 1L) {
            for (j in 1:k) {

                g = g + igraph::sample_gnp(n, p)

            }
        }

        # randomly add weights
        add_weights = sample.int(2, 1) == 1

        if (add_weights)
            igraph::E(g)$weight = rpois(igraph::ecount(g), 10)

        # randomly add labels
        add_labels = sample.int(2, 1) == 1

        iso = which(igraph::degree(g) == 0)

        if (add_labels)
            igraph::V(g)$name = paste0("v", igraph::V(g))

        c1 = igraph::components(g)$membership

        adj = if (add_weights) {

            igraph::as_adj(g, attr = "weight", sparse = FALSE)

        } else {

            igraph::as_adj(g, sparse = FALSE)

        }

        elist = mobmat_to_dat(adj)

        if (add_labels)
            elist[, `:=`(i = paste0("v", i + 1), j = paste0("v", j + 1))]

        c2 = get_components(elist, FALSE)

        if (add_labels) {

            # Note:
            #
            # need separate check since when edgelist ids are characters,
            # get_components will order the results based on name chars,
            # while igraph will keep the order of nodes as set when
            # creating the graph object

            # check no of components
            expect_identical(length(unique(c1)), length(unique(c2$component)))

            # check correspondents (although order might differ)
            check_tab = table(c1[order(names(c1))], c2$component)
            expect_identical(sum(check_tab != 0), nrow(check_tab))

            # check names
            expect_identical(names(c1)[order(names(c1))], c2$name)

        } else {

            expect_identical(c1, c2$component)

        }

        expect_identical(igraph::is.connected(g), is_connected(elist, FALSE))

        # order
        elist2 = adj
        expect_equal(get_components(elist2, FALSE)$component, c1, check.attributes = FALSE)

    }

    adj2 = adj
    adj2[2, 1] = .1

    elist2 = copy(elist)
    elist3 = copy(elist)
    elist2[, i := as.numeric(i)]
    elist2[2, 1] = .1

    elist3[, y := as.numeric(y)]
    elist3[2, 3] = .1

    # non integer matrix/elist
    expect_error(get_components(adj2, FALSE))
    expect_error(get_components(elist2, FALSE))
    expect_error(get_components(elist3, FALSE))

    # wrong dimensions
    expect_error(get_components(elist[, 1:2], FALSE))
    expect_error(get_components(cbind(elist, 1), FALSE))
    expect_error(get_components(adj[, -nrow(adj)], FALSE))
    expect_error(get_components(adj[-nrow(adj), ], FALSE))
    expect_error(get_components(adj[, -1], FALSE))
    expect_error(get_components(adj[-1, ], FALSE))

}

### EOF ###