#' Create edgelist to be fed into algorithm
#'
#' @param x a 3-column data.table or matrix
#' @return returns a list of two elements:
#' \itemize{
#' \item{\code{x}}{a 3-column \code{matrix} that can be fed into the  \code{sbm} function}
#' \item{\code{vnames}}{a \code{data.table} containing the mapping between the integer ids and original names}
#' }
#' Not exported.
precondition_data = function(x) {

    i = j = id = NULL

    if (
        "array" %in% class(x) ||
        ("data.frame" %in% class(x) && "data.table" %in% class(x) == F)
    )
        x = as.data.table(x)

    # get ids
    ids = sort(unique(unlist(x[, 1:2])))

    # check ids
    if (!is.character(ids) && any(ids %% 1 != 0))
        stop("node id/names have to be either characters or integers")

    # create table
    vnames = setDT(list(name = ids))

    # if ids are 0...(n-1) integers just return
    if (all(vnames == seq_along(vnames$name) - 1L))
        return(
            list(
                x = x,
                vnames = data.table(
                    id = seq_along(vnames$name) - 1L,
                    name = seq_along(vnames$name) - 1L
                )
            )
        )


    # create mapping from integers to names
    vnames[, id := seq_len(.N) - 1L]
    setcolorder(vnames, c("id", "name"))

    # standardize names
    setnames(x, c("i_old", "j_old", "y"))

    # replace
    x[vnames, i := id, on = c("i_old" = "name")]
    x[vnames, j := id, on = c("j_old" = "name")]

    # drop unnecessary columns
    x[, `:=`(i_old = NULL, j_old = NULL)]
    setcolorder(x, c("i", "j", "y"))

    return(list(x = x, vnames = vnames))

}

### EOF ###