#include <RcppArmadillo.h>
#include "init_spectral.h"
#include "utils/symmetrize.h"
#include "utils/kmeans.h"
//[[Rcpp::depends(RcppArmadillo)]]

//' Spectral clustering algorithm to obtain initial values for sparse mobility tables
//'
//' @param x mobility matrix
//' @param G number of clusters to extract
//' @param K number of dimensions to extract from graph Laplacian
//' @param sym_type integer equal to either 1 (simple, \code{A + A.t()}), 2 (bibliometric, \code{AA.t() + A.t()A}), or 3 (degree-pruned version of bibliometric symmetrization)
//' @param normalized boolean; whether the normalized Laplacian should be used
//' @param verbose boolean; whether to print out intermediate output
//[[Rcpp::export(.get_inits_spectral_sparse)]]
Rcpp::List get_inits_spectral_sparse(
    const arma::umat &x, 
    arma::uword G, 
    arma::uword K, 
    arma::uword sym_type,
    bool normalized,
    int verbose
){
    
    arma::uword N = x.cols(0, 1).max() + 1L;
    
    arma::vec eigval;
    arma::mat eigvec;
    bool eig_success(false);
        
    arma::sp_mat A(x.cols(0, 1).t(), arma::conv_to<arma::vec>::from(x.col(2)), N, N);
    
    if (verbose > 0)
        Rcpp::Rcout << "Symmetrizing Matrix ..." << std::endl;
    
    if (sym_type > 0) 
        A = symmetrize(A, sym_type);

    arma::rowvec d(arma::sum(A, 0L));
    
    if (verbose > 0)
        Rcpp::Rcout << "Eigen-decomposing Laplacian ..." << std::endl;
    
    // total degree sqrt
    if (normalized) {
        
        arma::sp_mat D(size(A));
        D.diag() = arma::pow(d, -0.5);
        
        A = D * A * D;
        eig_success = arma::eigs_sym(eigval, eigvec, A, K + 1L, "la");
        
        if (!eig_success) 
            eig_success = arma::eigs_sym(eigval, eigvec, arma::symmatl(A), K + 1L, "la");
        
    } else {
        
        A = arma::diagmat(d) - A;
        eig_success = arma::eigs_sym(eigval, eigvec, A, K + 1L, "sa");
        
        if (!eig_success && !A.is_symmetric())
            eig_success = arma::eigs_sym(eigval, eigvec, arma::symmatl(A), K + 1L, "sa");
        
    }
    
    if (!eig_success)
        Rcpp::stop("Eigen-decomposition failed ...");
        
    eigvec = eigvec.head_cols(K).t();
    
        
    if (verbose > 0)
        Rcpp::Rcout << "Clustering via K-means ..." << std::endl;
    
    
    // run kmeans    
    return run_kmeans(eigvec, N, G, verbose);

}



//' Spectral clustering algorithm to obtain initial values for dense mobility tables
//'
//' @param x mobility matrix
//' @param G number of clusters to extract
//' @param K number of dimensions to extract from graph Laplacian
//' @param sym_type integer equal to either 1 (simple, \code{A + A.t()}), 2 (bibliometric, \code{AA.t() + A.t()A}), or 3 (degree-pruned version of bibliometric symmetrization)
//' @param normalized boolean; whether the normalized Laplacian should be used
//' @param verbose boolean; whether to print out intermediate output
//[[Rcpp::export(.get_inits_spectral_dense)]]
Rcpp::List get_inits_spectral(
    const arma::umat &x, 
    arma::uword G, 
    arma::uword K, 
    arma::uword sym_type,
    bool normalized,
    int verbose
){
    
    arma::uword N = x.cols(0, 1).max() + 1L;
    
    arma::vec eigval;
    arma::mat eigvec;
    bool eig_success(false);
    
    arma::mat A(N, N, arma::fill::zeros);
    for (arma::uword i = 0; i < x.n_rows; ++i) {
     
     arma::urowvec x_i = x.row(i);
     A(x_i(0L), x_i(1L)) = x_i(2L);
     
    }
     
    if (verbose > 0)
     Rcpp::Rcout << "Symmetrizing Matrix ..." << std::endl;
    
    if (sym_type > 0)
    A = symmetrize(A, sym_type);
     
    if (verbose > 0)
     Rcpp::Rcout << "Eigen-decomposing Laplacian ..." << std::endl;
    
    arma::rowvec d(arma::sum(A, 0L));
     
    // total degree sqrt
    if (normalized) {
     
     arma::mat D = diagmat(arma::pow(d, -0.5));
     A = arma::eye(N, N) - D * A * D;;
     
    } else {
     
        A = arma::diagmat(d) - A;
         
    }
     
    eig_success = arma::eig_sym(eigval, eigvec, A);

    if (!eig_success)
        Rcpp::stop("Eigen-decomposition failed ...");
    
    eigvec = eigvec.cols(1, K).t();
        
    if (verbose > 0)
        Rcpp::Rcout << "Clustering via K-means ..." << std::endl;
    
    return run_kmeans(eigvec, N, G, verbose);
     
}

// EOF //
