#' Simulate mobility table from stochastic blockmodel
#'
#' Simulates a mobility matrix from Poisson distribution with log-rate specified by entered parameters
#'
#' @param lpsi image matrix
#' @param lpi block proportions
#' @param lalpha row-effects
#' @param lbeta column-effects
#' @param ldelta diagonal-effects
#' @param mu grand mean (on the log-scale). Defaults to 0.
#' @param z latent block memberships
#' @param N number of row/columns (if none of \code{lalpha, lbeta, ldelta} are given)
#' @param index integer; the number with which indexing of the blocks should start. Defaults to 0.
#' @param sparse booolean; if TRUE, returns a sparse matrix; otherwise dense.
#' @details all parameters should be defined on the log-scale
#' @return returns a list of two elements: (1) the simulated mobility matrix and (2) the block-memberships
#' @export
sim_sbm_poisson = function(
    lpsi,
    lpi,
    lalpha = NULL,
    lbeta = NULL,
    ldelta = NULL,
    mu = 0,
    z = NULL,
    N = NULL,
    index = 0L,
    sparse = FALSE
){

    if (all(is.null(lalpha), is.null(lbeta), is.null(ldelta), is.null(N)))
        stop("not all of lalpha, lbeta, ldelta, and N can be NULL")

    if (ncol(lpsi) != nrow(lpsi))
        stop("lpsi has to be a square matrix")

    if (ncol(lpsi) != length(lpi))
        stop("nrow(lpsi) has to be equal to length(lpi)")

    if (!is.null(z) && !all(z >= index))
        stop("some elements in z are smaller than z")

    if (is.null(N)) {

        N = if (!is.null(lalpha)) {

            length(lalpha)

        } else if (!is.null(lbeta)) {

            length(lbeta)

        } else {

            length(ldelta)

        }

    }

    if (index < 0 || index > 1 || index %% 1 != 0)
        stop("index has to be 0 or 1")

    if (!is.null(lalpha) && !is.null(lbeta) && length(lalpha) != length(lbeta))
        stop("lalpha and lbeta have to be of the same length")

    if (!is.null(lalpha) && !is.null(ldelta) && length(lalpha) != length(ldelta))
        stop("lalpha and ldelta have to be of the same length")

    if (!is.null(lbeta) && !is.null(ldelta) && length(lbeta) != length(ldelta))
        stop("lbeta and ldelta have to be of the same length")

    # no of blocks
    G = nrow(lpsi)

    # blocks
    if (is.null(z)) {

        z = sample( 1:G, N, TRUE, prob = exp(lpi) )

    } else {

        # check index of z
        min_z = min(z)

        if (!(min_z %in% c(0, 1)))
            stop("minimum value of z is not 0 or 1")

        # make sure that z starts with 1
        z = z + 1 - min_z

    }

    # get linear predictor
    xbmat = mu + lpsi[z[1:N], z[1:N]]

    if (!is.null(lalpha))
        xbmat = xbmat + matrix(lalpha, N, N)

    if (!is.null(lbeta))
        xbmat = xbmat + t(matrix(lbeta, N, N))

    if (!is.null(ldelta))
        xbmat = xbmat + diag(ldelta)

    mobmat = suppressWarnings(
        matrix(rpois(N * N, exp(xbmat)), nrow = N, ncol = N)
    )

    if (sparse)
        mobmat = Matrix::Matrix(mobmat, sparse = TRUE)

    return(list(mobmat = mobmat, z = z - 1 + index))

}

### EOF ###