# cd /N/project/fb/data/processed_data/edgelist/weekly_weighted_giant/comment/edgelists
# srun -c8 -t1:00:00 --mem=16GB -p debug --pty /bin/bash
# module load r/4.2.1
# R

suppressPackageStartupMessages({
    library(data.table)
    library(sbmob)
    library(arrow)
})

el = read_parquet("2016-10-27_346937065399354.parquet", as_data_frame = TRUE) |> setDT()
fit = cpm(el, sparse = TRUE)
