#' Helper function for printing (not exported)
#'
#' @param x string
#' @return aligns string right
align_right = function(x) {

    stopifnot(inherits(x, "character"))

    mc = max(nchar(x))
    sapply(x, function(w) { paste0(strrep(" ", mc - nchar(w)), w) })

}

#' Print method (S3)
#'
#' @param x an object of class \code{sbmob-sbm}
#' @param width the width of the output
#' @param ... further arguments passed to or from other methods
#' @export
`print.sbmob-sbm` = function(x, width = 40, ...) {

    x = c(
        length(x$post_z),
        length(x$lpi),
        x$converged,
        formatC(x$elbo, digits = 2, format = "f"),
        formatC(x$ICL, digits = 2, format = "f")
    ) |>
        align_right()

    x = cbind(
        c("Number of nodes  : ",
          "Number of blocks : ",
          "Converged        : ",
          "Final ELBO       : ",
          "ICL              : "),
        x
    ) |>
        apply(1L, paste0, collapse = "")

    mc = max(nchar(x))

    if (mc < width) {

        d = width - mc
        mc = width
        x = gsub(":", paste0(":", strrep(" ", d)), x)

    }


    cat("Stochastic Blockmodel Fit\n")
    cat(strrep("-", mc), "\n")
    cat(x[1], "\n")
    cat(x[2], "\n")
    cat(x[3], "\n")
    cat(x[4], "\n")
    cat(x[5], "\n")
    cat(strrep("-", mc), "\n")

}

### EOF ###