library(arrow)
library(data.table)
library(sbmob)

# data
el = setDT(read_parquet('./bugfiles/anne/2015-01-01_15704546335.parquet'))

#  get components
components = data.table(sbmob::get_components(el))

# table() to get size of every component, in descending order
table = components[, .N, by = component]

# if there is more than one component subset the giant
if (dim(table)[1] > 1) {
    
    print('disconnected, getting giant component')
    giant_comp = table[which.max(N), ]$component
    giant_nodes = components[component == giant_comp, ]$name
    giant_el = el[(i %in% giant_nodes) | (j %in% giant_nodes), ]
    
    # always check
    stopifnot(is_connected(giant_el))
    
    fit = cpm(giant_el, gen_inits = "random", verbose = T, sparse = TRUE)
    
}



# 
# Oh I forgot to mention, instead of this:
# 
# table = setorder(data.table(table(components$component)), cols = -"N")
# 
# you can do this:
# 
# table = components[, .N, by = component]
#  
# microbenchmark::microbenchmark(
#     table = components[, .N, by = component],
#     table2 = setorder(data.table(table(components$component)), cols = -"N")
# )
# 
# # Unit: milliseconds
# # expr       min        lq      mean    median        uq       max neval
# # table  1.851355  1.975686  2.307417  2.132017  2.387665  4.684367   100
# # table2 18.726514 19.703341 20.622772 20.521459 21.151889 24.207523   100
# 
# 
# # error prone
# Also, this is a bit error prone, if for some reason the sorting changes (you are directly sort on rows but not on columns). 
# giant_comp = table[[1, 1]]
# 
# In general, it is advisable to use "numbers" in coding as little as possible. So, instead of that, the following is less error-prone (you wouldn't even need to sort the table):
# 
# giant_comp = table[which.max(N)]$component
# 
# all.equal(giant_comp, giant_comp2)
