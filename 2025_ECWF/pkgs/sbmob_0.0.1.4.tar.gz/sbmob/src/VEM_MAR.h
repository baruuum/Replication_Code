#ifndef VEM_MAR_H
#define VEM_MAR_H

#include "VBase.h"
#include "utils/matrix_lfactorial.h"

using Eigen::MatrixXd;
using Eigen::VectorXd;
using Eigen::ArrayXd;
using Eigen::ArrayXXd;
using Eigen::RowVectorXd;

typedef Eigen::SparseMatrix<double> SpMat;
typedef Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic, Eigen::RowMajor> Rmat;

template <typename T> 
class VEM_MAR : public VBase<T>
{
    
protected:
    
    using VBase<T>::m_y;
    using VBase<T>::m_G;
    using VBase<T>::m_nodes;
    
    using VBase<T>::lxi;
    using VBase<T>::lpsi;
    using VBase<T>::lpi;
    
    long double lfact_y;
    
    int m_iter, m_verbose;
    double m_elbo;                     // elbo
    std::vector<double> m_elbo_hist;   // elbo history
    
public:
    
    // constructors
    VEM_MAR(
        const T& mobmat, 
        const MatrixXd& lxi_inits, 
        int verbose
    );
    VEM_MAR(
        const T& mobmat,
        const MatrixXd& lxi_inits,
        const MatrixXd& lpsi_inits,
        const VectorXd& lpi_inits,
        int verbose
    );
    
    void estep(int estep_maxit, double estep_tol, bool debug);
    void mstep();
    void fit(int maxit, double tol, int estep_maxit, double estep_tol, bool debug = false);
    void update_elbo();
    
    MatrixXd get_lpsi() const { return lpsi; };
    VectorXd get_lpi() const {return lpi; };
    MatrixXd get_lxi() const { return lxi; };
    double get_elbo() const { return m_elbo; };
    std::vector<double> get_elbo_hist() const {return m_elbo_hist; };
    double get_icl(const T& mobmat) const ;

};

template<> void VEM_MAR<MatrixXd>::estep(int estep_maxit, double estep_tol, bool debug);
template<> void VEM_MAR<SpMat>::estep(int estep_maxit, double estep_tol, bool debug);

extern template class VEM_MAR<MatrixXd>;
extern template class VEM_MAR<SpMat>;

#endif
