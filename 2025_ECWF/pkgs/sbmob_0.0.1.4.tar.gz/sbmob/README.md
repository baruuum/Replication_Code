
<!-- README.md is generated from README.Rmd. Please edit that file -->

# sbmob

<!-- badges: start -->

[![Lifecycle:Experimental](https://img.shields.io/badge/Lifecycle-Experimental-339999)](Redirect-URL)
[![R-CMD-check](https://github.com/baruuum/sbmob/workflows/R-CMD-check/badge.svg)](https://github.com/baruuum/sbmob/actions)
<!-- badges: end -->

The `sbmob` package fits stochastic blockmodels to mobility tables using
a variational EM algorithm, where each entry of the mobility table is
assumed to be Poisson distributed. Either degree-corrected versions or
vanilla stochastic blockmodels be fitted with the function.

## Installation

The development version can be installed from
[GitHub](https://github.com/) with:

``` r
# install.packages("devtools")
devtools::install_github("baruuum/sbmob")
```

## Unit test resutls

Unit tests can be found in the `inst/tinytest` directory. The last runs
passed on May 16, 2022 with the following results:

``` r
> tinytest::test_all()
Running test_components.R.............   69 tests OK 0.1s
Running test_data.R...................   55 tests OK 0.2s
Running test_initis_vem.R.............   18 tests OK 52ms
Running test_blockcompare.R...........   60 tests OK 41ms
Running test_elbo.R...................    1 tests OK 67ms
Running test_utils_cpp.R..............   27 tests OK 42ms
Running test_vem_cpp.R................    4 tests OK 0.1s
Running test_vem_mar_cpp.R............    2 tests OK 20ms
Running test_vestep_cpp.R.............    9 tests OK 1.2s
Running test_vestep_mar_cpp.R.........    9 tests OK 1.1s
Running test_vmstep_cpp.R.............   12 tests OK 1.4s
Running test_vmstep_mar_cpp.R.........    4 tests OK 49ms
Running test_local.R..................    0 tests    4.1s
Running test_loglin_block.R...........   27 tests OK 0.2s
Running test_sbm.R....................   13 tests OK 0.5s
All ok, 182 results (5.1s)
```
