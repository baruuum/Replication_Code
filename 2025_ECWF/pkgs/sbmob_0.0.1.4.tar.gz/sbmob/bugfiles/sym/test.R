# 
# dat = fread("bugfiles/sym/tmp.csv")
# x = dat_to_mobmat(dat)
# saveRDS(x, "bugfiles/sym/mat.rds")

src = "
#include <RcppArmadillo.h>
//[[Rcpp::depends(RcppArmadillo)]]
using namespace Rcpp;

inline arma::mat diag_deg_sqrt(const arma::mat& x, arma::uword type = 0L) {

    arma::vec s(x.n_cols);
    
    if (type == 0) {
        s = arma::sum(x, 0).t();
    } else {
        s =  arma::sum(x, 1);
    }
    
    
    arma::mat D = arma::diagmat(arma::pow(s, -0.5));
    
    return D;

}

//[[Rcpp::export]]
arma::mat testfun(arma::mat A, bool force) {
    
    arma::mat D_i = diag_deg_sqrt(A, 0);
    arma::mat D_o = diag_deg_sqrt(A, 1);
            
    arma::mat B = (D_o * A * D_i * A.t() * D_o) + (D_i * A.t() * D_o * A * D_i);
    
    arma::mat A_sym(B);
    
    if (force) 
        A_sym = arma::symmatl(B);
    
    Rcpp::Rcout << std::boolalpha << D_i.is_diagmat() << std::endl;
    Rcpp::Rcout << std::boolalpha << D_o.is_diagmat() << std::endl;
    Rcpp::Rcout << std::boolalpha << A_sym.is_symmetric() << std::endl;
    
    
    arma::vec eigvals;
    arma::mat eigvecs;
    
    arma::eig_sym(eigvals, eigvecs, A_sym);
    
    return eigvecs;

}
"

Rcpp::sourceCpp(code = src)

x = readRDS("bugfiles/sym/mat.rds")
dat = fread("bugfiles/sym/tmp.csv")
a = create_inits_spectral(
   dat, 2, 1, sparse = F, symmetrize = 3, normalized = F 
)
b = create_inits_spectral(
    dat, 2, 1, sparse = T, symmetrize = 3, normalized = F 
)


x = matrix(as.numeric(x), nrow(x), ncol(x))
res1 = testfun(x, F)
res2 = testfun(x, T)

y = x
diag(y) = 0
res3 = testfun(y, F)
res4 = testfun(y, T)
