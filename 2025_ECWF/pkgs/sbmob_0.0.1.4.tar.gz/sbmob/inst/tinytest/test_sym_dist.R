library("sbmob")

n = 10
x = matrix(runif(n^2), n)
mode = seq.int(4)
pnorm = 1:3

for (m in mode) {

    s = switch(m,
        { # m = 1
            x
        },
        { # m = 2
            x + t(x)
        },
        { # m = 3
            x %*% t(x) + t(x) %*% x
        },
        { # m = 4

            dj = sqrt(diag(1 / rowSums(x)))
            di = sqrt(diag(1 / colSums(x)))

            dj %*% x %*% di %*% t(x) %*% dj + di %*% t(x) %*% dj %*% x %*% di

        }
    )

    if (m > 1) {

        stopifnot(isSymmetric(s))

    } else {

        # transpose because "dist" function calculates distances between rows,
        # while get_symmetrized_distanes calculates it between columns
        s = t(s)

    }

    for (p in pnorm) {

        d = dist(s, method = "minkowski", p = p)
        res_r = as.matrix(d)
        dimnames(res_r) = NULL
        res_cpp = sym_dist(x, sym_type = m - 1L, p = p, lower_only = F)

        # check
        expect_equal(res_r, res_cpp)

        # check only lower
        res_lower_cpp = sym_dist(x, sym_type = m - 1L, p = p, lower_only = T)
        expect_equal(as.numeric(d), res_lower_cpp[, 3])

    }

}

### EOF ###