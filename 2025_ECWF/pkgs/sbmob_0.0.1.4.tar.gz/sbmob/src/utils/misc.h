#ifndef MISC_H
#define MISC_H

#include <RcppEigen.h>


// -------------------------------------------------------------
// Block indicator related funcs
// -------------------------------------------------------------

//' get indices to sort vector in descending order
//'
//' @param x vector to be sorted
//' @return returns the indices to sort vector in decending order (not sorting the vector itself)
//' @details the function is used in sample_log.h
inline Eigen::VectorXi sort_index_desc(const Eigen::VectorXd &x) {
    
    std::vector<int> idx(x.size());
    
    // create indices
    std::iota(idx.begin(), idx.end(), 0L);
    
    // sort indices
    std::stable_sort(
        idx.begin(), idx.end(), [&x](double i, double j) { return x[i] > x[j]; } 
    );
    
    // map back to Eigen
    int *ptr = &idx[0];
    Eigen::Map<Eigen::VectorXi> res(ptr, x.size());
    
    return res;
}

//' get number of unique values of an ArrayXi
//' 
//' @param z integer array
//' @return returns the number of unique elements in z
inline int uniqueN_z(const Eigen::ArrayXi& z) {
    
    std::set<int> u{z.data(), z.data() + z.size()};
    return u.size();
    
}

//' count num of obs in block
//' 
//' @param z an integer array to check
//' @param K the number of unique values that "should" be contained in z
//' @param min_occ the minimum occurence allowed for each unique element
//' @return returns an array with number of occurrences bounded above by \code{min_occ}
inline Eigen::ArrayXi block_sizes(const Eigen::ArrayXi& z, int K, int min_occ) {
    
    Eigen::ArrayXi tab = Eigen::ArrayXi::Zero(K);
    
    for (int i = 0; i < z.size(); ++i) 
        if (tab(z(i)) <= min_occ)
            ++tab(z(i));
        
    return tab;
    
}

//' check whether all blocks have more obs than a minimum
//' 
//' @param z an integer array to check
//' @param K the number of unique values that "should" be contained in z
//' @param min_occ the minimum occurence allowed for each unique element
//' @return returns \code{true} if each element in z occurs at least \code{min_occ} times
inline bool check_block_sizes(const Eigen::ArrayXi& z, int K, int min_occ) {
    
    Eigen::ArrayXi tab = block_sizes(z, K, min_occ);
    return (tab >= min_occ).all();
        
}

//' get the first occurrence of {0, 1, ..., K} within an ArrayXi 
//' 
//' @param z array of blockmemberships
//' @param K number of blocks
//' @return returns the first index in z for each block
inline Eigen::ArrayXi get_first_indx_of_block(const Eigen::ArrayXi& z, int K) {
    
    int N = z.size();
    Eigen::ArrayXi indx = Eigen::ArrayXi::Zero(K);
    indx += -1L;
    
    for (int k = 0; k < K; ++k) {
        
        for (int i = 0; i < N; ++i) {
            
            if (z(i) == k) {
                
                indx(k) = i;
                break;
                
            }
            
            if (i == N - 1) {
                
                Rcpp::String s("Index for block ");
                s += k;
                s += " not found";
                Rcpp::stop(s);
                
            }
            
        }
        
    }
    
    return indx;
    
}

//' set indices of vector to zero
//' 
//' @param x vector
//' @param indx integer array containing the indices at which x should be set to zero
//' @param N total size of mobility matrix
//' @return changes values of x at indices to zero (in-place)
template <typename T>
inline void set_indx_zero(T& x, const Eigen::ArrayXi& indx, int N) {
    
    if (x.size() == N) {

        for (int k = 0; k < indx.size(); ++k)
            x(indx(k)) = 0;
        
    } else if (x.size() == N - 1L){
        
        // assuming that the first element is dropped
        // (which should be 0 anyways, since it's by construction the first element in a class)
        
        for (int k = 1; k < indx.size(); ++k)
            x(indx(k) - 1L) = 0;
        
    } else {
        
        Rcpp::stop("Cannot set indx to zero due to dimension mismatch");
        
    }
    
    return ;
    
}

// -------------------------------------------------------------
// Set Diagonals to Zero
// -------------------------------------------------------------

inline void set_diagonals_zero(Eigen::MatrixXd& x) 
{
    
    // note:
    // unfortunately this code will *not* work for sparse matrices
    x.diagonal().setZero();
    
}

inline void set_diagonals_zero(Eigen::SparseMatrix<double>& x){
 
    for (int i = 0; i < x.rows(); ++i)
        if (x.coeff(i, i) != 0.0)
            x.coeffRef(i, i) = 0.0;

    if (!x.isCompressed())
        x.makeCompressed();
    
}

#endif
