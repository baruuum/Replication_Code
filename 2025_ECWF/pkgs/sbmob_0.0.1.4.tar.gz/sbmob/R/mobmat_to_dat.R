#' @title Reshape between mobility table and (weighted) edgelist
#' @name reshape
#' @aliases mobmat_to_dat
#' @aliases dat_to_mobmat
#' @rdname reshape
#' @param mobmat mobility matrix
#' @param dat a \code{data.table} object with three columns: (1) the row index, (2) the column index, and (3) the value
#' @param index starting index used when reshaping from mobility table to edgelist; must be either 0 or 1
#' @param diags when creating mobility matrix from rectangular data, whether to keep the diagonal cells ("as_is"; the default), set them to zero ("zero"), or set them to NA ("NA"). When \code{sparse = TRUE} and \code{diags = NA}, the diagonals of the resulting matrix will be set to "." (i.e., no data entry).
#' @param sparse boolean; whether to return a sparse matrix
#' @param N dimension of the mobility matrix
#' @param keep_isolates boolean; whether to keep isolated notes when transforming matrix to data
#' @return creates mobility matrix from edgelist or vice versa
#' @details When creating an edgelist from a mobility table, special attention has to be paid to the \code{index} option. When creating a mobility table from an edgelist, on the other hand, whether the index starts from 0 or 1 is immaterial.
NULL

#' @rdname reshape
#' @export
mobmat_to_dat = function(mobmat, index = 0L, keep_isolates = TRUE) {

    i = j = y = NULL

    stopifnot(
        ("array" %in% class(mobmat) || "dgCMatrix" %in% class(mobmat)),
        length(dim(mobmat)) == 2L,
        dim(mobmat)[1] == dim(mobmat)[2],
        index %in% 0:1
    )


    if ("dgCMatrix" %in% class(mobmat)) {

        if (!keep_isolates) {

            dat_long = data.table::data.table(Matrix::summary(mobmat))
            setnames(dat_long, "x", "y")

            if (index == 0) {

                dat_long[, i := i - 1L]
                dat_long[, j := j - 1L]

            }

            return(dat_long)

        } else {

            mobmat = as.matrix(mobmat)

        }

    }

    n = NCOL(mobmat)
    colnames(mobmat) = paste0("V", 2:(n + 1))

    dat = data.table::data.table(cbind(V1 = 1:n, mobmat))
    dat_long = data.table::melt(dat, id.var = "V1", variable.name = "j", value.name = "y")
    data.table::setnames(dat_long, "V1", "i")

    if (index == 0) {

        dat_long[, j := as.integer(gsub("V", "", j)) - 2L]
        dat_long[, i := i - 1L]

    } else {

        dat_long[, j := as.integer(gsub("V", "", j) ) - 1L]

    }

    if (!keep_isolates)
        dat_long = dat_long[y != 0]

    return(dat_long)

}

#' @rdname reshape
#' @export
dat_to_mobmat = function(dat, diags = c("as_is", "zero", "NA"), sparse = FALSE, N = NULL) {

    i = j = y = NULL

    diags = match.arg(diags)

    if (ncol(dat) != 3)
        stop("dat must have three columns")

    setnames(dat, c("i", "j", "y"))
    indx1 = as.integer(dat[, min(i, j)] == 1)

    if (sparse) {

        dims = if (is.null(N)) rep(max(dat$i, dat$j) - indx1 + 1, 2) else rep(N, 2)

        if (diags == "as_is") {

            mobmat = Matrix::sparseMatrix(
                i = dat[y != 0]$i,
                j = dat[y != 0]$j,
                x = dat[y != 0]$y,
                index1 = indx1,
                dims = dims
            )

        } else {

            mobmat = Matrix::sparseMatrix(
                i = dat[i != j & y != 0]$i,
                j = dat[i != j & y != 0]$j,
                x = dat[i != j & y != 0]$y,
                index1 = indx1,
                dims = dims
            )

        }

        dimnames(mobmat) = list(NULL, NULL)

    } else {

        # get node sequence
        node_seq = if (!is.null(N)) {
            seq_len(N) + indx1 - 1
        } else {
            seq_len(max(dat$i, dat$j) + (1 - indx1)) + indx1 - 1
        }

        # cast to wide format
        d = dcast(dat, i ~ j, value.var = "y", fill = 0L)

        # get not-included senders
        m_rows = setdiff(node_seq, unique(d$i))

        if (length(m_rows) > 0) {

            # empty matrix of zeros
            d_add = data.table(
                cbind(i = m_rows, matrix(0, nrow = length(m_rows), ncol = ncol(d) - 1))
            )
            setnames(d_add, names(d))

            # add to matrix
            d = rbind(d, d_add)
            d = d[order(i)]

        }

        # get non-included receivers
        m_cols = setdiff(node_seq, as.integer(names(d[, -1])))

        if (length(m_cols) > 0)
            d[, (as.character(m_cols)) := 0]

        d[, i := NULL]
        setcolorder(d, as.character(node_seq))

        mobmat = as.matrix(d)

        if (diags != "as_is")
            diag(mobmat) = switch(
                diags,
                zero = 0,
                `NA`   = NA
            )

        dimnames(mobmat) = NULL

    }

    return(mobmat)

}

### EOF ###