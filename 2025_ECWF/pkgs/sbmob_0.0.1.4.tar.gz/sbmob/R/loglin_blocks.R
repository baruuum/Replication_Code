#' Fit log-linear (poisson) model to mobility table
#'
#' fits a log-linear model with row effects, column effects, blocked-out diagonals, and block effects using the \code{glm} function
#'
#' @param x a \code{data.table} object with three columns
#' \itemize{
#' \item{\code{i}}{row index}
#' \item{\code{j}}{column index}
#' \item{\code{y}}{count of observations}
#' }
#' @param z integer vector containing the block assignments of each row/column
#' @param sparse_glm if \code{TRUE} runs conjugate gradient descent for sparse design matrices
#' @return returns a list of two elements:
#' \itemize{
#' \item{}{a \code{glm.fit} object of the fitted log-linear model (if \code{sparse_glm} is \code{FALSE}) or a list otherwise}
#' \item{}{a \code{matrix} of goodness-of-fit statistics}
#' }
#' @export
loglin_blocks = function(x, z, sparse_glm = TRUE) {

    # need this to pass CRAN test
    i = j = zi = zj = NULL

    # model = match.arg(model)

    # need to make deep copy as data matrix will be manipulated
    dat = copy(x)

    # block diagonals
    if (dat[, any(i == j)]) {

        diag_dat = dat[i == j]
        dat = dat[i != j]

    } else {

        diag_dat = NULL

    }


    # indices
    ij = c(dat$i, dat$j)
    ij_lim = c(min(ij), max(ij))
    z_lim = c(min(z), max(z))

    # check all ids are present
    if (!isTRUE(identical(sort(unique(ij)), seq(ij_lim[1], ij_lim[2], 1L))))
        stop(
            "Some node indices are missing in x. ",
             "Indices have to increase sequentially from either 0 or 1"
        )

    if (!isTRUE(identical(sort(unique(z)), seq(z_lim[1], z_lim[2], 1L))))
        stop(
            "Some block indices are missing in z. ",
            "Indices have to increase sequentially from either 0 or 1"
        )

    if (ij_lim[1] == 0) {

        if (length(z) != ij_lim[2] + 1L)
            stop("size mismatch between indices in dat and z")

    } else if (ij_lim[1] == 1) {

        if (length(z) != ij_lim[2])
            stop("size mismatch between indices in dat and z")

    } else {

        stop("occupation indices have to start from either 0 or 1")

    }

    # add classes
    if (ij_lim[1] == 0) {

        dat[, `:=`(zi = z[i + 1L], zj = z[j + 1L])]

    } else if (ij_lim[1] == 1) {

        dat[, `:=`(zi = z[i], zj = z[j])]

    }

    # start generating formula
    f = "y ~ -1"

    # generate dummies for row/column effects
    for (ii in seq(ij_lim[1], ij_lim[2])) {

        rc = paste0(c("row_", "col_"), ii)
        dat[
            , c(rc) := list(as.integer(i == ii), as.integer(j == ii))
        ]

        # update formula
        f = paste0(f, " + ", paste0(rc, collapse = " + "))

    }

    # generate dummies for classes
    z_unique = sort(unique(z))

    for (z1 in z_unique) {
        for (z2 in z_unique) {

            z1z2 = paste0("class_", z1, "_", z2)

            dat[, c(z1z2) := as.integer(zi == z1 & zj == z2)]

            # update formula
            f = paste0(f, " + ", paste0(z1z2, collapse = " + "))

        }
    }

    # add constraints to formula (one row/col marginal per class is set to zero)
    zero_set = sapply(unique(z), function(w) min(which(z == w)))

    if (ij_lim[1] == 0)
        zero_set = zero_set - 1L

    constraints = c(
        paste0("\\+ row_", zero_set, "\\b"),
        paste0("\\+ col_", zero_set, "\\b")
    )
    f = gsub(paste0(constraints, collapse = "|"), "", f)

    # if single occ class exists, add additional constraints
    singular = z_unique[which(table(z) == 1)]

    if (length(singular) > 0) {

        add_consts = paste0("\\+ class_", singular, "_", singular, "\\b")

        if (length(add_consts) > 1)
            add_consts = paste0(add_consts, collapse = "|")

        f = gsub(add_consts, "", f)

    }

    # fit model
    fit = if (sparse_glm) {

            res = .sparse_glm(
                dat$y,
                Matrix::sparse.model.matrix(as.formula(f), data = dat),
                type = 1,
                tol = 1e-7,
                maxit = 50,
                verbose = 0
            )
            names(res$coefficients) = trimws(strsplit(f, "\\+")[[1]][-1])
            res$fitted.values = as.numeric(res$fitted.values)
            res

        } else {

            glm(
                as.formula(f),
                data = dat,
                family = poisson(link = "log")
            )

        }

    # check coefs
    if (any(is.na(coef(fit))))
        stop("some coefficients are NA, suggesting wrong constraints")


    # note: deviance is the same regardelss of whether diagonals are included
    #       or not, since the same value is added to the saturated log
    #       likelihood and the model likelihood (diagonals are perfectly fitted);
    #       the same is true for the Pearson X^2 statistics, since the numerator
    #       of the statistic is 0 for all diagonal cells; lastly, the df.residual
    #       remains the same as well, since n cells added to the data as well as
    #       to the number of parameters (i.e., the "blocked" diagonals)
    fit_tab = matrix(NA, nrow = 2L, ncol = 3L)
    fit_tab[1, 1] = fit$deviance
    fit_tab[1, 2] = fit$df.residual
    fit_tab[1, 3] = pchisq(fit_tab[1, 1], df = fit_tab[1, 2], lower.tail = F)
    fit_tab[2, 1] = sum((dat$y - fit$fitted.values)^2 / fit$fitted.values)
    fit_tab[2, 2] = fit_tab[1, 2]
    fit_tab[2, 3] = pchisq(fit_tab[2, 1], df = fit_tab[2, 2], lower.tail = F)
    colnames(fit_tab) = c("statistic", "df", "p-value")
    rownames(fit_tab) = c("G2", "X2")

    # model log-likelihood & df & n
    ll = if (sparse_glm) { fit$loglik } else { as.numeric(logLik(fit)) }
    df = length(fit$coefficients)
    n  = nrow(dat)

    if (!is.null(diag_dat)) {

        ll_diag = ll + sum(dpois(diag_dat$y, diag_dat$y, log = TRUE))
        df_diag = df + NROW(diag_dat)
        n_diag  = n + NROW(diag_dat)

    } else {

        ll_diag = ll
        df_diag = df
        n_diag = n

    }

    # AIC and BIC
    ic_tab = matrix(NA, 4, 5)
    ic_tab[1, 1] = ic_tab[3, 1] = ll
    ic_tab[2, 1] = ic_tab[4, 1] = ll_diag
    ic_tab[1, 2] = ic_tab[3, 2] = n
    ic_tab[2, 2] = ic_tab[4, 2] = n_diag
    ic_tab[1, 3] = ic_tab[3, 3] = df
    ic_tab[2, 3] = ic_tab[4, 3] = df_diag
    ic_tab[1, 4] = 2 * df
    ic_tab[2, 4] = 2 * df_diag
    ic_tab[3, 4] = log(n) * df
    ic_tab[4, 4] = log(n_diag) * df_diag
    ic_tab[1, 5] = -2.0 * ll + 2 * df
    ic_tab[2, 5] = -2.0 * ll_diag + 2 * df_diag
    ic_tab[3, 5] = -2.0 * ll + log(n) * df
    ic_tab[4, 5] = -2.0 * ll_diag + log(n_diag) * df_diag

    rownames(ic_tab) = c("AIC", "AIC (with diag)", "BIC", "BIC (with diag)")
    colnames(ic_tab) = c("ll", "n", "df", "penalty", "IC")

    return(
        list(
            fit = fit,
            fit_tab = fit_tab,
            ic_tab = ic_tab,
            ll = ll,
            formula = f
        )
    )

}

### EOF ###