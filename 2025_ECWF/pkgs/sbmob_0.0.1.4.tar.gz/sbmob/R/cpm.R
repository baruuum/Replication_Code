#' Fit core-periphery model to mobility data
#'
#' @param x 3-column \code{data.table} object containing the edge list with the following columns
#' \itemize{
#' \item{i}{sender (first column), index should start from zero}
#' \item{j}{receiver (second column), index should start from zero}
#' \item{y}{count of workers(third column)}
#' }
#' or a square \code{matrix} object of integers, where the rows represent the senders and columns the receiving nodes.
#' @param inits initial values
#' @param gen_inits a string of either "spectral" (spectral clustering) or "random" (random initial values), which controls how initial values are generated.
#' @param spectral_type a string that specifies what type of spectral clustering to use. This argument is relevant only if \code{gen_inits == "spectral"} (see details).
#' @param spectral_dims integer smaller than \code{nblocks}; the number of eigenvectors to extract for spectral clustering
#' @param retry_init boolean; if \code{TRUE} retries to create initial values using eigen decomposition using sparse representation of data (if \code{sparse == TRUE}, it will retry using dense representation)
#' @param sparse boolean; whether to treat mobility matrix as a sparse matrix
#' @param check_connected checks whether graph is connected before running model; defaults to \code{TRUE}.
#' @param normalized_params if \code{TRUE} estimated parameters with "sum-to-zero" constraints are returned; otherwise, estimated parameters based on dummy-coding will be returned. Defaults to \code{FALSE}
#' @param n_threads number of threads to use (needs OpenMP support)
#' @param verbose integer; controls the verbosity of the function with higher values producing more output
#' @param control list of control parameters for the VEM algorithm (see details)
#' @return returns a list of the following elements:
#' \itemize{
#' \item \code{elbo}: the maximized ELBO
#' \item \code{elbo_hist}: the history of the ELBO optimization
#' \item \code{ICL}: the integrated classification likelihood
#' \item \code{lalpha}: the row-effects
#' \item \code{lbeta}: the column-effects
#' \item \code{lmu} : the grand-mean if \code{normalized_params} is set to \code{TRUE}; the intercept otherwise
#' \item \code{lpi}: the estimated block proportions
#' \item \code{lpsi}: the image matrix
#' \item \code{lxi}: the variational parameters (i.e., approximation to posterior class probabilities)
#' \item \code{post_z}: MAP of blockmembership
#' \item \code{node_names}: a \code{data.table} object containing the mapping from the row number of the \code{lxi} matrix to the original node names
#' \item \code{strength}: the strength of the core-periphery structure. See details.
#' }
#' @details
#' The function fits a Poisson SBM without degree-correction with two blocks to the data. The model is fitted to the off-diagonal entries of the data matrix, which corresponds to "blocking" the diagonal cells by fitting a separate parameter to each of them (except one). If desired, the diagonal parameters can be recovered after the estimation procedure noting that the diagonal cells of the data matrix will be fitted perfectly. Notice as well that the "penalty term" in the ICL counts the parameters for the diagonal cells, even if they are not estimated directly. For specificaiton of the options, see help file of [sbmob::sbm()]
#'
#' The only additional object that is returned is the \code{strength} of the core-periphery structure. This measure is calculated as the absolute value of the difference in the average strength of the within-block connections. Let \eqn{s_1} and \eqn{s_2} be, respectively, the sum of the edge-weights allocated within block 1 and 2, and let \eqn{n_1} and \eqn{n_2} be their relatative size. Then the strength of the core-periphery structure is calculated as \deqn{\Sigma = \left\vert \frac{s_1}{n_1 (n_1 - 1)} - \frac{s_2}{n_2(n_2 -1)}\right\vert.} In the case of unweighted graphs, this reduces to \eqn{\Sigma = \vert D_1 - D_2 \vert}, where \eqn{D_1} and \eqn{D_2} are the densities of each block.
#' @export
cpm = function(
        x,
        inits = NULL,
        gen_inits = c("spectral", "random"),
        spectral_type = c(
            "default",
            "dc",
            "dc_norm",
            "bib",
            "bib_norm",
            "simple",
            "simple_norm"
        ),
        spectral_dims = 0L,
        retry_init = TRUE,
        sparse = FALSE,
        check_connected = TRUE,
        normalized_params = FALSE,
        n_threads = 1L,
        verbose = 1L,
        control = list()
){

    res = sbm(
        x,
        2L,
        inits,
        "diagonal",
        gen_inits,
        spectral_type,
        spectral_dims,
        retry_init,
        sparse,
        check_connected,
        normalized_params,
        n_threads,
        verbose,
        control
    )

    class(res) = append(class(res), "sbmob-cpm")

    return(res)

}

### EOF ###