library("Matrix")
library("sbmob")

# no of nodes
n = 5L
base_mat = matrix(rpois(n * n, 100), nrow = n, ncol = 5)

for (ii in 1:5) {

    mobmat = if (ii == 1) {

        base_mat

    } else if (ii == 2) {

        # zero out degree
        base_mat[2, ] = 0
        base_mat

    } else if (ii == 3) {

        # zero in degree
        base_mat[, 2] = 0
        base_mat

    } else if (ii == 4) {

        # isolate with diag
        base_mat[2, ] = 0
        base_mat[, 2] = 0
        base_mat[2, 2] = 5
        base_mat

    } else {

        # isolate without diag
        base_mat[2, ] = 0
        base_mat[, 2] = 0
        base_mat

    }


    # check equivalence between sparse and dense
    expect_equal(
        mobmat_to_dat(mobmat, keep_isolates = FALSE),
        mobmat_to_dat(Matrix::Matrix(mobmat, sparse = TRUE), keep_isolates = FALSE)
    )

    expect_equal(
        mobmat_to_dat(mobmat, keep_isolates = TRUE),
        mobmat_to_dat(Matrix::Matrix(mobmat, sparse = TRUE), keep_isolates = TRUE)
    )

    expect_equal(
        mobmat_to_dat(mobmat, index = 1, keep_isolates = FALSE),
        mobmat_to_dat(Matrix::Matrix(mobmat, sparse = TRUE), index = 1, keep_isolates = FALSE)
    )

    expect_equal(
        mobmat_to_dat(mobmat, index = 1, keep_isolates = TRUE),
        mobmat_to_dat(Matrix::Matrix(mobmat, sparse = TRUE), index = 1, keep_isolates = TRUE)
    )

    # check reshape
    expect_equal(
        dat_to_mobmat(mobmat_to_dat(mobmat, 1), diags = "as_is"),
        mobmat,
        check.attributes = FALSE
    )

    # reshape - sparse
    expect_equal(
        dat_to_mobmat(mobmat_to_dat(mobmat, 1), diags = "as_is", sparse = TRUE),
        Matrix::Matrix(mobmat, sparse = TRUE),
        check.attributes = FALSE
    )

    # indexing
    expect_equal(
        dat_to_mobmat(mobmat_to_dat(mobmat, 0), diags = "as_is"),
        mobmat,
        check.attributes = FALSE
    )

    # indexing - sparse
    expect_equal(
        dat_to_mobmat(mobmat_to_dat(mobmat, 0), diags = "as_is", sparse = TRUE),
        Matrix::Matrix(mobmat, sparse = TRUE),
        check.attributes = FALSE
    )

    # zero diags
    mobmat_zero = mobmat
    diag(mobmat_zero) = 0

    expect_equal(
        dat_to_mobmat(mobmat_to_dat(mobmat, 1), diags = "zero"),
        mobmat_zero,
        check.attributes = FALSE
    )

    # zero diags - sparse
    expect_equal(
        dat_to_mobmat(mobmat_to_dat(mobmat, 1), diags = "zero", sparse = TRUE),
        Matrix::Matrix(mobmat_zero, sparse = TRUE),
        check.attributes = FALSE
    )

    # na diags
    mobmat_na = mobmat
    diag(mobmat_na) = NA

    expect_equal(
        dat_to_mobmat(mobmat_to_dat(mobmat, 1), diags = "NA"),
        mobmat_na,
        check.attributes = FALSE
    )

    # na diags - sparse
    expect_equal(
        dat_to_mobmat(mobmat_to_dat(mobmat, 1), diags = "NA", sparse = TRUE),
        Matrix::Matrix(mobmat_zero, sparse = TRUE),
        check.attributes = FALSE
    )

    # errors
    expect_error(mobmat_to_dat(mobmat, 2))

}

### EOF ###