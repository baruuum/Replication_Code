#ifndef INIT_SPECTRAL_H
#define INIT_SPECTRAL_H

#include <RcppArmadillo.h>

Rcpp::List get_inits_spectral(
        const arma::umat &x, 
        arma::uword G, 
        arma::uword K, 
        arma::uword seed_mode,
        bool sparse,
        arma::uword symmetrize = 2,
        bool normalized = true,
        int verbose = 0
);
    
#endif
