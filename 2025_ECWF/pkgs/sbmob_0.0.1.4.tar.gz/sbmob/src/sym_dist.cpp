//[[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include "utils/symmetrize.h"

//' Calculate distance matrix symmetrized matrix
//'
//' @param x a numeric matrix
//' @param sym_type an integer; 0 returns distances between the \emph{columns} of \code{x} without symmetrization, 1: after "simple" symmetrization (\code{x * t(x)}), 2: "bibliometric" symmetrization, and 3: "degree-corrected bibliometric" symmetrization
//' @param p an integer; determines which of the L^p norms should be calculated for the distances. Defaults to 1 (Manhattan distance)
//' @param lower_only boolean; if \code{TRUE}, returns only the lower part of the distance matrix in the form of \code{[i, j, d]}, where \code{i} is the row index, \code{j} the column index, and \code{d} the distance; indices start from 0.
//' @param return_distances boolean; if \code{TRUE}, returns the distances between columns of symmetrized matrix; otherwise, returns the symmetrized matrix itself 
//' @return returns a distance matrix of the same size as \code{x}.
//' @export
//[[Rcpp::export]]
arma::mat sym_dist(
    const arma::mat &x, 
    arma::uword sym_type = 3L,
    arma::uword p = 1L,
    bool lower_only = false,
    bool return_distances = true
) {
    
    // check entries
    if (arma::any(arma::vectorise(x) < 0.0) && sym_type == 3)
        Rcpp::stop("Entries of x have to be non-negative when sym_type == 3");
    
    if (!x.is_square())
        Rcpp::stop("x has to be a square matrix");
    
    if (p <= 0)
        Rcpp::stop("p has to be a positive integer");
    
    // get dims and initialize matrix
    arma::uword N = x.n_cols;
    arma::mat S(x);
    
    // symmetrize
    if (sym_type > 0) {
        
        S = symmetrize(S, sym_type);
        
        if (!S.is_symmetric(1e-08))
            Rcpp::stop("Matrix is not symmetric after symmetrization");
        
    }

    if (!return_distances)
        return S;
        
    // distance matrix
    arma::mat dist_lower;
    
    if (lower_only) {
        
        dist_lower.set_size(N * (N - 1L) / 2L, 3L);
        
        arma::uword cc(0L);
        for (arma::uword j = 0; j < N; ++j) {
            for (arma::uword i = j + 1; i < N; ++i) {
                
                dist_lower(cc, 0L) = i;
                dist_lower(cc, 1L) = j;
                dist_lower(cc, 2L) = arma::norm(S.col(i) - S.col(j), p);
                
                ++cc;
                
            }
        }
            
        return(dist_lower);
        
    } 
    
    dist_lower.set_size(N, N);
    dist_lower.diag().zeros();
    
    for (arma::uword j = 0; j < N; ++j)
        for (arma::uword i = j + 1; i < N; ++i)
            dist_lower(i, j) = arma::norm(S.col(i) - S.col(j), p);

    return arma::symmatl(dist_lower);
    
}

// EOF //
