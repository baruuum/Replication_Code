#ifndef IRLS_POISLL_H
#define IRLS_POISLL_H

#include <RcppEigen.h>
#include "../utils/model_matrix.h"
#include "../utils/matrix_lfactorial.h"

namespace irls_pois {

using Eigen::MatrixXd;
using Eigen::VectorXd;
using Eigen::ArrayXd;
using Eigen::ArrayXi;
using Eigen::SparseQR;
using Eigen::LeastSquaresConjugateGradient;
using Eigen::LeastSquareDiagonalPreconditioner;

typedef Eigen::SparseMatrix<double> SpMat;

class PoisLL {
    
protected:
    
    VectorXd m_y;       // outcome vector
    SpMat m_x;          // model matrix
    int m_N, m_K;       // row and column of m_X
    int m_nodes, m_G;   // no of nodes and blocks
    ArrayXi m_zero_indx;
    VectorXd m_b;       // reg coefficients
    ArrayXd m_mu;       // predictions
    double m_dev;       // deviance
    bool m_type;        // type of decomposition to use
    double m_tol;       // tolerance
    int m_maxit;        // max no of iterations
    int m_verbose;      // verbosity
    
    double m_ll0;         // saturated ll
    
public:
    
    // constructor (dense)
    PoisLL(
        const MatrixXd &y, 
        const ArrayXi& z,
        int type,
        double tol,
        int maxit,
        int verbose
    ) : m_dev(std::numeric_limits<double>::infinity()),
        m_type(type),
        m_tol(tol),
        m_maxit(maxit),
        m_verbose(verbose)
    {
        
        m_nodes = z.size();
        m_G = uniqueN_z(z);
        m_zero_indx = get_first_indx_of_block(z, m_G);
        
#ifdef DEBUG
        Rcpp::Rcout<< "nodes & blocks: " << m_nodes << "," << m_G << std::endl;
#endif
        
        m_y = mat_offdiag_to_vec(y);
        m_mu = m_y.array() + 0.1;
        m_x = model_matrix(z, m_zero_indx);
        m_N = m_x.rows();
        m_K = m_x.cols();
        
        VectorXd m_b = VectorXd::Zero(m_K);
        
        m_ll0 = 0.0;
        for (int i = 0; i < m_N; ++i)
            if (m_y(i) > 0.0)
                m_ll0 += R::dpois(m_y(i), m_y(i), true);

    }
    // constructor (sparse)
    PoisLL(
        const SpMat &y, 
        const ArrayXi& z,
        int type,
        double tol,
        int maxit,
        int verbose
    ) : m_dev(std::numeric_limits<double>::infinity()),
    m_type(type),
    m_tol(tol),
    m_maxit(maxit),
    m_verbose(verbose)
    {
        
        m_nodes = z.size();
        m_G = uniqueN_z(z);
        m_zero_indx = get_first_indx_of_block(z, m_G);
        
        m_y = mat_offdiag_to_vec(y);
        m_mu = m_y.array() + 0.1;
        m_x = model_matrix(z, m_zero_indx);
        m_N = m_x.rows();
        m_K = m_x.cols();
        
        VectorXd m_b = VectorXd::Zero(m_K);
        
        m_ll0 = 0.0;
        for (int i = 0; i < m_N; ++i)
            if (m_y(i) > 0.0)
                m_ll0 += R::dpois(m_y(i), m_y(i), true);
        
    }
    
    //constructor (vector + model matrix)
    // constructor
    PoisLL(
        const VectorXd &y, 
        const SpMat &x, 
        int type,
        double tol,
        int maxit,
        int verbose)
        : m_y(y),
          m_x(x),
          m_N(m_x.rows()),
          m_K(m_x.cols()),
          m_nodes(0L),
          m_G(0L),
          m_zero_indx(0),
          m_b(m_x.cols()),
          m_mu(y.array() + 0.1),
          m_dev(std::numeric_limits<double>::infinity()),
          m_type(type),
          m_tol(tol),
          m_maxit(maxit),
          m_verbose(verbose) 
    {
        
        m_ll0 = 0.0;
        for (int i = 0; i < m_N; ++i)
            if (m_y(i) > 0.0)
                m_ll0 += R::dpois(m_y(i), m_y(i), true);   
        
    }
    
    // member functions
    void update_fitted() { m_mu = (m_x * m_b).array().exp(); };
    void update_beta_wls();
    void update_deviance();
    
    void maximize();
    
    VectorXd get_beta() { return m_b; };
    double get_deviance() {return m_dev; };
    ArrayXd get_fitted() { return m_mu; };
    double get_loglik() { return m_ll0 - 0.5 * m_dev; };
    
    VectorXd get_parvec() { 

        VectorXd alpha = VectorXd::Zero(m_nodes);
        VectorXd beta = VectorXd::Zero(m_nodes); 
        
        MatrixXd psi(m_G, m_G);
        psi << m_b.tail(m_G * m_G);
        psi.transposeInPlace();
    
        int cc(0L);
        for (int i = 0; i < m_nodes; ++i) {
            
            if (!(m_zero_indx == i).any()) {
                
                alpha(i) = m_b(cc);
                beta(i) = m_b(cc + m_nodes - m_G);
                
                ++cc;
                
            }
            
        }
        
        VectorXd pars(2 * m_nodes + m_G * m_G);
        pars << alpha, beta, psi;
        
        return pars;
        
    };

};



//' Weighted least squares regression
//'
//' @param y outcome vector
//' @param x model matrix
//' @param w weight vector
//' @param whether to use cholesky factorization in calculating the solution; defaults to \code{false}, which uses the Householder QR decomposition with column pivoting.
//' @return coefficients from WLS regression
//' @details Calculates \eqn{(X'WX)^{-1}X'Wy}. 
inline void PoisLL::update_beta_wls() {
    
    ArrayXd pseudo_y = m_mu.log() + m_y.array() / m_mu - 1.0;
    SpMat xw = m_mu.sqrt().matrix().asDiagonal() * m_x;
    
    if (m_type == 0) {
        
        SparseQR<SpMat, Eigen::COLAMDOrdering<int>> SQR(xw);
        
        if (SQR.info() != Eigen::Success)
            Rcpp::stop("QR decomposition failed");
        
        m_b = SQR.solve((pseudo_y * m_mu.sqrt()).matrix());
        
        if (SQR.info() != Eigen::Success)
            Rcpp::stop("QRSolver solving failed");
        
    } else {
        
        LeastSquaresConjugateGradient<SpMat, LeastSquareDiagonalPreconditioner<double>> CG(xw);
        m_b = CG.solve((pseudo_y * m_mu.sqrt()).matrix());
        
        if (CG.info() != Eigen::Success)
            Rcpp::stop("CG Solver solving failed");
        
    }
    
    return;
    
}

inline void PoisLL::update_deviance() {
    
    using std::log;
    
    double f(0.0);
    
    for (int i = 0; i < m_N; ++i) {
        
        f += m_mu(i);
            
        if (m_y(i) > 0.0)
            f += m_y(i) * (log(m_y(i)) - log(m_mu(i))) - m_y(i);

    }
    
    m_dev = 2.0 * f;
    
    return;
    
}


//' IRLS algorithm for Poisson distributed outcome
//'
//' @param b initial value of regression coefficients
//' @param y outcome vector
//' @param x model matrix (either \code{MatrixXd} or \code{SparseMatrix<double>})
//' @param tol tolerance
//' @param maxit maximum iterations
//' @param cholesky whether to use the cholesky factorization in wls procedure
inline void PoisLL::maximize()
{
    
    double dev_old = m_dev;
    int iter(0L);
    for (; iter < m_maxit; ++iter) {
        
        update_beta_wls();
        update_fitted();
        update_deviance();
        
        if (m_verbose > 0)
            Rcpp::Rcout << "iteration : " << iter + 1L <<
                ", (cond) log-likelihood : " << get_loglik() << std::endl;

        if ((dev_old - m_dev) < m_tol * dev_old)
            break;
        
        dev_old = m_dev;
        
    }
    
    if (iter == m_maxit)
        Rcpp::Rcout << "Warning: maxit reached" << std::endl;
    
    return;
    
}


} // namespace irls_pois


// explicit instantiation
// template class irls_pois::PoisLL<Eigen::MatrixXd>;
// template class irls_pois::PoisLL<Eigen::SparseMatrix<double>>;

#endif
