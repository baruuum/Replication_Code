#' Fit stochastic blockmodel to mobility data
#'
#' @param x 3-column \code{data.table} or \code{data.frame} object containing the edge list with the following columns
#' \itemize{
#' \item{i}{sender (first column), index should start from zero}
#' \item{j}{receiver (second column), index should start from zero}
#' \item{y}{count of workers(third column)}
#' }
#' or a square \code{matrix} object of integers, where the rows represent the senders and columns the receiving nodes.
#' @param nblocks an integer indicating the number of blocks to fit. Must be greater than 1.
#' @param model either "qindep" (default), or "diagonal" (see details)
#' @param inits initial values
#' @param gen_inits a string of either "spectral" (spectral clustering) or "random" (random initial values), which controls how initial values are generated.
#' @param spectral_type a string that specifies what type of spectral clustering to use. This argument is relevant only if \code{gen_inits == "spectral"} (see details).
#' @param spectral_dims integer smaller than \code{nblocks}; the number of eigenvectors to extract for spectral clustering. Defaults to \code{spectral_dims = 0} using \code{nblocks - 1} dimensions.
#' @param retry_init boolean; if \code{TRUE} retries to create initial values using eigen decomposition using sparse representation of data (if \code{sparse == TRUE}, it will retry using dense representation)
#' @param sparse boolean; whether to treat mobility matrix as a sparse matrix (experimental)
#' @param check_connected checks whether graph is connected before running model; defaults to \code{TRUE}.
#' @param normalized_params if \code{TRUE} estimated parameters with "sum-to-zero" constraints are returned; otherwise, estimated parameters based on dummy-coding will be returned. Defaults to \code{FALSE}
#' @param n_threads number of threads to use (needs OpenMP support; experimental)
#' @param verbose integer; controls the verbosity of the function with higher values producing more output
#' @param control list of control parameters for the VEM algorithm (see details)
#' @return returns a list of the following elements:
#' \itemize{
#' \item \code{elbo}: the maximized ELBO
#' \item \code{elbo_hist}: the history of the ELBO optimization
#' \item \code{ICL}: the integrated classification likelihood
#' \item \code{lalpha}: the row-effects
#' \item \code{lbeta}: the column-effects
#' \item \code{lmu} : the grand-mean if \code{normalized_params} is set to \code{TRUE}; the intercept otherwise
#' \item \code{lpi}: the estimated block proportions
#' \item \code{lpsi}: the image matrix
#' \item \code{lxi}: the variational parameters (i.e., approximation to posterior class probabilities)
#' \item \code{post_z}: MAP of blockmembership
#' \item \code{node_names}: a \code{data.table} object containing the mapping from the row number of the \code{lxi} matrix to the original node names
#' }
#' @details
#' The function fits either a degree-corrected version of the Poisson SBM (when \code{model == "qindep"}) or one without degree-correction (when \code{model == "diagonal"}). In both of them, the model is fitted to the off-diagonal entries of the data matrix, which corresponds to "blocking" the diagonal cells by fitting a separate parameter to each of them (except one). If desired, the diagonal parameters can be recovered after the estimation procedure noting that the diagonal cells of the data matrix will be fitted perfectly. Notice as well that the "penalty term" in the ICL counts the parameters for the diagonal cells, even if they are not estimated directly. Support for sparse mobility matrices and multithreading still at an experimental stage.
#'
#' @section Initial values:
#' The \code{spectral_type} option specifies (1) the method to symmetrize a directed graph into an undirected one on which spectral clustering can be performed (2) and whether the Laplacian or the normalized Laplacian matrix should be used for the clustering. Possible options are "bib" (bibliometric symmetrization), "bib_norm" (bibliometric symmetrization with normalized Laplacian), simple" (\code{X + t(X)}), "simple_norm" (\code{X + t(X)} with normalized Laplacian), "dc" (degree-corrected bibliometric symmetrization), "dc_norm" (degree-corrected bibliometric symmetrization with normalized Laplacian). The default is "dc_norm" when \code{model == "qindep"} and "bib_norm" if \code{model == "diagonal"}.
#'
#' @section Control argument:
#' The following options can be specified in the \code{control} argument, which should be entered as a named list. The parameters and default values are: \code{list(maxit = 50, tol = 1e-07, estep_maxit = 30, estep_tol = 1e-07, mstep_m = 6, mstep_epsilon = 1e-07, mstep_past = 1, mstep_delta = 1e-07, mstep_maxit = 100, mstep_maxlinesearch = 30, stable_density_calc = FALSE, debug = FALSE)}, where
#' \itemize{
#'     \item \code{maxit}: maximum number of (outer) iterations of the VEM algorithm
#'     \item \code{tol}: the tolerance to declare convergence
#'     \item \code{estep_maxit}: maximum number of E-step iterations to perform at each outer iteration
#'     \item \code{estep_tol}: tolerance to declare convergence of the E-step at each outer iteration
#'     \item \code{mstep_m}: the memory of the L-BFGS algorithm in approximating the Hessian
#'     \item \code{mstep_epsilon}: the tolerance to declare convergence for the M-step at each outer iteration. The L-BFGS algorithm is considered to have converged when the norm of the gradient is smaller than \code{mstep_epsilon}
#'     \item \code{mstep_past}: the number of past steps to compare against when checking convergence of the M-step, e.g., when \code{mstep_past == k} the ELBO at iteration \code{t} will be compared with the ELBO at iteration \code{t - k}.
#'     \item \code{mstep_delta}: the tolerance to declare convergence for the M-step at each outer iteration. The L-BFGS algorithm is considered to have converged when | ELBO(\code{t}) - ELBO(\code{t - mstep_past})| is smaller than \code{mstep_delta}.
#'     \item \code{mstep_maxit}: maximum number of M-step iterations to perform within each outer iteration
#'     \item \code{mstep_maxlinesearch}: maximum number of line search iterations to perform in each M-step iteration
#'     \item \code{stable_density_calc}: whether a numerically more stable version of the ELBO should be calculated. In most cases, this option can be set to \code{FALSE} without resulting in under or overflow.
#'     \item \code{debug}: depreciated argument used for debugging
#' }
#'
#' @export
sbm = function(
    x,
    nblocks,
    inits = NULL,
    model = c("qindep", "diagonal"),
    gen_inits = c("spectral", "random"),
    spectral_type = c(
        "default",
        "dc",
        "dc_norm",
        "bib",
        "bib_norm",
        "simple",
        "simple_norm"
    ),
    spectral_dims = 0L,
    retry_init = TRUE,
    sparse = FALSE,
    check_connected = TRUE,
    normalized_params = FALSE,
    n_threads = 1L,
    verbose = 1L,
    control = list()
){

    # helper function
    init_list_to_lxi = function() {

        t(
            log(
                apply(
                    init_list$dist,
                    1L,
                    function(w) {
                        tmp = exp(-w^2)
                        tmp / sum(tmp)
                    }
                )
            )
        )

    }

    ## ------------------------------------------------------------------
    ## Check arguments
    ## ------------------------------------------------------------------

    # init type
    gen_inits = match.arg(gen_inits)

    # model
    model = match.arg(model)
    is_qindep = (model == "qindep")

    # spectral type and dims
    spectral_type = match.arg(spectral_type)
    stopifnot(spectral_dims %% 1 == 0)

    # data
    stopifnot(
        inherits(x, "data.frame"),
        NCOL(x) == 3,
        all(names(x) == c("i", "j", "y")),
        all(x$y %% 1 == 0)
    )

    # check blocks
    stopifnot(nblocks > 1)

    # precondition data & get node name mapping
    pre_list = precondition_data(x)
    x = pre_list$x

    # number of obs
    n = max(x[, 1:2]) + 1L

    if (check_connected && !is_connected(x))
        stop("x must be a connected graph. If you want to run the model regardless, set check_connected to FALSE.")


    ## ------------------------------------------------------------------
    ## VEM control arguments
    ## ------------------------------------------------------------------

    con = list(
        maxit = 50,
        tol = 1e-07,
        estep_maxit = 30,
        estep_tol = 1e-07,
        mstep_m = 6,
        mstep_epsilon = 1e-07,
        mstep_past = 1,
        mstep_delta = 1e-07,
        mstep_maxit = 100,
        mstep_maxlinesearch = 30,
        stable_density_calc = FALSE,
        debug = FALSE
    )

    # check args
    if (length(control) != 0 && any(names(control) %in% names(con) == FALSE))
        stop("control list provided but names do not match")

    # update controls
    con[names(control)] = control

    ## ------------------------------------------------------------------
    ## Initial values
    ## ------------------------------------------------------------------

    if (is.null(inits)) {

        inits = if (gen_inits == "random") {

            init_list = list(dist = matrix(runif(n * nblocks), nrow = n))
            init_list_to_lxi()

        } else {

            # number of eigenvecs to extract in spectral clustering
            if (spectral_dims == 0)
                spectral_dims = nblocks - 1L

            # resolve default
            spectral_type = if (spectral_type == "default") {

                if (is_qindep) "dc_norm" else "bib_norm"

            } else {

                spectral_type

            }

            normalize = grepl("^.+_norm$", spectral_type)
            stype = gsub("^([a-z]+)(_norm)*$", "\\1", spectral_type)
            stype = switch(
                stype,
                simple = 1L, bib = 2L, dc = 3L,
                stop("Cannot resolve spectral_type")
            )

            init_list = create_inits_spectral(
                x, nblocks, spectral_dims, sparse, stype, normalize, retry_init, verbose
            )
            init_list_to_lxi()

        }

    }

    ## ------------------------------------------------------------------
    ## Fit model
    ## ------------------------------------------------------------------

    if (is_qindep) {

        if (sparse) {

            res = .fit_vem_sparse(
                dat_to_mobmat(x, diags = "as_is", sparse = TRUE),
                inits,
                n_threads,
                verbose,
                con
            )

        } else {

            res = .fit_vem(
                dat_to_mobmat(x, diags = "as_is"),
                inits,
                n_threads,
                verbose,
                con
            )

        }

    } else {

        if (sparse) {

            res = .fit_vem_mar_sparse(
                dat_to_mobmat(x, diags = "as_is", sparse = TRUE),
                inits,
                n_threads,
                verbose,
                con
            )

        } else {

            res = .fit_vem_mar(
                dat_to_mobmat(x, diags = "as_is"),
                inits,
                n_threads,
                verbose,
                con
            )

        }

    }

    # grand mean (sum-to-zero) or intercept (dummy-coding) on log-scale
    lmu = 0.0

    if (normalized_params) {

        if (model == "qindep") {

            lalpha = c(0, res$lalpha)
            m_lalpha = mean(lalpha)
            res$lalpha = lalpha - m_lalpha

            lbeta = c(0, res$lbeta)
            m_lbeta = mean(lbeta)
            res$lbeta = lbeta - m_lbeta

            lmu = m_lalpha + m_lbeta

        }

        lpsi = res$lpsi
        m_lpsi = mean(lpsi)
        res$lpsi = lpsi - m_lpsi

        lmu = lmu + m_lpsi

    } else {

        if (model == "qindep") {

            res$lalpha = c(0, res$lalpha)
            res$lbeta = c(0, res$lbeta)

        }

        lmu = NULL

    }

    res$lmu = lmu
    res$post_z = apply(res$lxi, 1L, which.max)

    res = res[order(names(res))]

    # node mapping
    id = NULL # to avoid CRAN notes
    n_map = pre_list$vnames
    n_map[, id := id + 1L]
    setnames(n_map, "id", "row_indx")

    res$node_names = n_map

    # convergence
    res$converged = con$maxit - length(res$elbo_hist) > 0

    # set class
    class(res) = append(class(res), "sbmob-sbm")

    return(res)

}

### EOF ###