## ------------------------------------------------------------------
## initialization
## ------------------------------------------------------------------

library(sbmob)
library(Matrix)

## ------------------------------------------------------------------
## Generate data
## ------------------------------------------------------------------

n = 50
k = 3
g = 2
mobmat = matrix(
    rpois(n * n, 5),
    nrow = n
)
dat = as.matrix(sbmob::mobmat_to_dat(mobmat, index = 0))

## ------------------------------------------------------------------
## Compare sparse to dense
## ------------------------------------------------------------------

runcombs = expand.grid(symmetrize = 1:3, normalize = c(T, F))

for (i in seq_len(nrow(runcombs))) {

    res1 = sbmob::create_inits_spectral(
        x = dat,
        G = g,
        D = k,
        sparse = TRUE,
        symmetrize = runcombs[i, "symmetrize"],
        normalized = runcombs[i, "normalize"],
        verbose = 0
    )

    res2 = sbmob::create_inits_spectral(
        x = dat,
        G = g,
        D = k,
        sparse = FALSE,
        symmetrize = runcombs[i, "symmetrize"],
        normalized = runcombs[i, "normalize"],
        verbose = 0
    )

    expect_equal(res1$sq_dist, res2$sq_dist)

}



## ------------------------------------------------------------------
## Compare with hand calculations
## ------------------------------------------------------------------

for (i in seq_len(nrow(runcombs))) {

    # i = 3 fails!

    sym = runcombs[i, "symmetrize"]
    norm = runcombs[i, "normalize"]

    X = mobmat
    diag(X) = 0

    res = sbmob::create_inits_spectral(
        x = dat,
        G = g,
        D = k,
        sparse = FALSE,
        symmetrize = sym,
        normalized = norm,
        verbose = 0
    )

    # generate laplacian
    X = if (sym == 1) {

        X + t(X)

    } else if (sym == 2) {

        X %*% t(X) + t(X) %*% X

    } else {

        Di = diag(1 / sqrt(colSums(X)))
        Do = diag(1 / sqrt(rowSums(X)))

        X = Do %*% X %*% Di %*% t(X) %*% Do +
            Di %*% t(X) %*% Do %*% X %*% Di

    }

    d = rowSums(X)

    if (norm) {

        dsqrt = diag(d^(-1/2))
        L = diag(nrow(X)) - dsqrt %*% X %*% dsqrt

    } else {

        L = diag(d) - X

    }


    # get eigen vectors
    evecs = eigen(L)$vectors[, (n - k) : (n - 1)]

    # reorder
    evecs = evecs[, k:1]

    expect_equal(abs(evecs), abs(res$eigvecs))

    # get clusters
    cc = res[[1]]
    ee = res[[2]]
    z = apply(ee, 1L, function(w) {

        which.min(apply(cc, 2L, function(v) sum((w - v)^2)))

    })  - 1

    expect_equal(as.vector(res[[3]]), z)

}

### EOF ###