#ifndef SYMMETRIZE_H
#define SYMMETRIZE_H

#include <RcppArmadillo.h>

using namespace Rcpp;

//' create diagonal matirx of the square root of in/outdegrees
//' 
//' @param x (weighted) adjacency matrix
//' @param type 0 for indegrees, 1 for outdegrees
inline arma::mat diag_deg_sqrt(const arma::mat& x, arma::uword type = 0L) {

    arma::vec s(x.n_cols);
    
    if (type == 0) {
        s = arma::sum(x, 0).t();
    } else {
        s =  arma::sum(x, 1);
    }
    
    
    arma::mat D(arma::size(x), arma::fill::zeros);
    D.diag() = arma::pow(s, -0.5);
    
    return D;

}

inline arma::sp_mat diag_deg_sqrt(const arma::sp_mat& x, arma::uword type = 0L) {
    
    arma::vec s(x.n_cols);
    
    if (type == 0) {
        s = arma::sum(x, 0).t();
    } else {
        s =  arma::sum(x, 1);
    }
    
    arma::sp_mat D(arma::size(x));
    D.diag() = arma::pow(s, -0.5);
    
    return D;
    
}



//' Symmetrizes a square matrix
//' 
//' @param A matrix to be symmetrized
//' @param type integer; 0 returns \code{A}; 1 "simple" symmetrization, 2: "bibliometric" symmetrization, 3: "degree-corrected bibliometric" symmetrization
//' @return void; symmetrizes \code{A} by reference
template <typename T>
inline T symmetrize(const T& A, arma::uword type) {
    
    switch(type) {
        
        case 1:
            
            return A + A.t();
            
        case 2:
            
            return A * A.t() + A.t() * A;

        case 3: {
                
            T D_i = diag_deg_sqrt(A, 0);
            T D_o = diag_deg_sqrt(A, 1);
            
            return (D_o * A * D_i * A.t() * D_o) + (D_i * A.t() * D_o * A * D_i);
            
        }
            
        default:
            
            Rcpp::stop("type has to be an integer between 0 and 3");
            
    }
    
    return A;
    
} 

// explicit instantiation
template arma::mat symmetrize<arma::mat>(const arma::mat& A, arma::uword type);
template arma::sp_mat symmetrize<arma::sp_mat>(const arma::sp_mat& A, arma::uword type);


#endif
