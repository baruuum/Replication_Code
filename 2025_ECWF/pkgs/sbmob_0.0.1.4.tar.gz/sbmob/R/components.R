#' helper function (checkin elements of edge list)
#'
#' @param x a data.table object or matrix
#' @param verbose whether to spit out some messages
#' @return returns the same object after checking elements
check_elist = function(x, verbose) {

    if ("matrix" %in% class(x)) {

        if (nrow(x) == ncol(x)) {

            x = mobmat_to_dat(x)

        } else {

            if(ncol(x) != 3)
                stop("elist has to be either a square matrix or an edgelist")

            x = as.data.table(x)

        }

    } else if ("data.frame" %in% class(x)) {

        if (ncol(x) != 3)
            stop("elist has to be either a square matrix or an edgelist with 3 columns")

    } else {

        stop("elist has to be either a matrix or data.frame")

    }

    if (any(unlist(x[, 3]) %% 1 != 0))
        stop("third column of input has to consist of integers only")

    # get node names
    pre_list = precondition_data(x)

    min_indx = min(unlist(pre_list$x[, 1:2]))
    N = nrow(pre_list$vnames)

    if (verbose) {

        message("Minimum index of edgelist is ", min_indx)
        message("Matrix is square of dimension ", N)
    }

    return(
        list(
            elist = as.matrix(pre_list$x),
            N = N,
            min_indx = min_indx,
            vnames = pre_list$vnames
        )
    )

}


#' Components of network
#'
#' Determines the (weakly connected) components of a graph from a (possibly weighted) edgelist using depth-first search
#'
#' @param elist either an (possibly weighted) adjacency matrix or a \code{data.table}, \code{data.frame}, or unsigned integer matrix with 3 columns (sender, receiver, weights)
#' @param verbose boolean whether to print out intermediate information
#' @returns a two-column \code{data.table} object containing the name and the component of each node of the graph. If nodes were unnamed in original graph, indices starting from 0 are returned in the name column.
#' @details Indices of the component vector starts from 1 and not 0
#' @export
get_components = function(elist, verbose = FALSE) {

    x = check_elist(elist, verbose)
    res = data.table::data.table(
        x$vnames$name,
        .get_components(x$elist, x$N, x$min_indx)
    )
    data.table::setnames(res, c("name", "component"))

    return(res)

}

#' Check whether graph is (weakly) connected
#'
#' @inheritParams get_components
#' @returns \code{TRUE} if graph is connected, \code{FALSE} otherwise
#' @export
is_connected = function(elist, verbose = FALSE) {

    comps = get_components(elist, verbose)
    return(!(length(unique(comps$component)) > 1))

}

### EOF ###