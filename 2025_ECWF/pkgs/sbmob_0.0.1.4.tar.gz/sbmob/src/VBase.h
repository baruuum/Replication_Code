#ifndef VBASE_H
#define VBASE_H

#include <RcppEigen.h>
#include "utils/expsums.h"
#include "utils/misc.h"

using Eigen::MatrixXd;
using Eigen::VectorXd;
using Eigen::SparseMatrix;

typedef Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic, Eigen::RowMajor> Rmat;

// -------------------------------------------------------------
// VE class
// -------------------------------------------------------------

template <typename T>
class VBase
{
    
protected:
    
    T m_y;                  // mobility matrix
    int m_G;                // number of classes
    int m_nodes;            // no. of nodes
        
    Rmat lxi;               // variational parameters
    MatrixXd lpsi;          // image matrix
    VectorXd lpi;           // class probabilities

public:
    
    // constructors
    VBase(const T& mobmat, const MatrixXd& lxi_inits);
    VBase(
        const T& mobmat,
        const MatrixXd& lxi_inits,
        const MatrixXd& lpsi_inits,
        const VectorXd& lpi_inits
    );
    // destructor
    virtual ~VBase() = default;
    
    void check_args();

};


template <typename T>
VBase<T>::VBase(
    const T& mobmat,     
    const MatrixXd& lxi_inits
) : m_y(mobmat),
    m_G(lxi_inits.cols()),
    m_nodes(lxi_inits.rows()),
    lxi(lxi_inits),
    lpsi(m_G, m_G),
    lpi(m_G)
{
    
    // setting diagonals of mobmat to zero
    set_diagonals_zero(m_y);
    
    // initialize
    lpi.setZero();
    lpsi.setZero();
        
    check_args();
    
}

template <typename T>
VBase<T>::VBase(
    const T& mobmat,
    const MatrixXd& lxi_inits,
    const MatrixXd& lpsi_inits,
    const VectorXd& lpi_inits
) : m_y(mobmat),
    m_G(lxi_inits.cols()),
    m_nodes(lxi_inits.rows()),
    lxi(lxi_inits), 
    lpsi(lpsi_inits), 
    lpi(lpi_inits)
{
    
    set_diagonals_zero(m_y);
    check_args();
    
}

template <typename T>
void VBase<T>::check_args() {
    
    int N = m_y.rows();
    
    if (m_nodes != N)
        Rcpp::stop("Dimension mismatch between lxi and mobmat");
    
    if (m_y.cols() != N)
        Rcpp::stop("mobility matrix is not square");
    
    if (lpi.size() != m_G)
        Rcpp::stop("Dimension mismatch in lpi");
    
    if (lpsi.rows() != m_G)
        Rcpp::stop("Dimension mismatch in lpsi");
    
    if (lpsi.cols() != lpsi.rows())
        Rcpp::stop("lpsi is not square");
    
    if (lxi.maxCoeff() > 1.0)
        Rcpp::stop("lxi values exceed 1.0");
    
    for (int i = 0; i < m_nodes; ++i)
        if (std::abs(lxi.row(i).array().exp().sum() - 1.0) > 1e-10)
            Rcpp::stop("rows of exp(lxi) don't sum to one");
        
    return ;
    
}

#endif
