#' Initialize via spectral clustering
#'
#' @param x matrix or \code{data.table} of 3 columns, in order, row index, col index, and value
#' @param G number of clusters
#' @param D number dimensions to extract from graph Laplacian
#' @param sparse boolean; whether the mobility table is sparse
#' @param symmetrize integer equal to either 1 (simple, \code{A + A.t()}), 2 (bibliometric, \code{AA.t() + A.t()A}), or 3 (degree-pruned version of bibliometric symmetrization).
#' @param normalized boolean; whether normalized Laplacian should be used
#' @param retry_init boolean; if \code{TRUE} retries to create initial values using eigen decomposition using sparse representation of data (if \code{sparse == TRUE}, it will retry using dense representation)
#' @param verbose boolean; whether to print out intermediate output
#' @return returns a list of four elmements: the centroids of the k-means algorithm, the eigenvectors of the graph Laplacian, the identified clusters, and the convergence code (\code{TRUE} if the k-means algorithm converged and \code{FALSE} otherwise)
#' @export
create_inits_spectral = function(
    x,
    G,
    D,
    sparse = FALSE,
    symmetrize = 2,
    normalized = TRUE,
    retry_init = TRUE,
    verbose = 1
) {

    if (inherits(x, "data.frame"))
        x = as.matrix(x)

    if (NCOL(x) != 3)
        stop("x has to have three columns: row index, col index, value (create_inits)")

    if (min(x[, 1:2]) != 0)
        stop("indices in x have to start from zero (create_inits)")

    if (any(x[, 3] < 0))
        stop("x[, 3] has to be non-negative (create_inits)")

    if (!(symmetrize %in% 1:3))
        stop("symmatrize has to be an integer between 1 and 3")

    # drop diagonals
    x = x[x[, 1] != x[, 2],]

    res = if (sparse) {

        tryCatch(
            .get_inits_spectral_sparse(x, G, D, symmetrize, normalized, verbose),
            error = function(e) {

                if (!retry_init) {

                    message(e)
                    return(e)

                }


                if (verbose > 0)
                    message("\nRetrying using dense matrix representation ...\n")

                .get_inits_spectral_dense(x, G, D, symmetrize, normalized, verbose)

            }
        )

    } else {

        tryCatch(
            .get_inits_spectral_dense(x, G, D, symmetrize, normalized, verbose),
            error = function(e) {

                if (!retry_init) {

                    message(e)
                    return(e)

                }

                if (verbose > 0)
                    message("\nRetrying using sparse matrix representation ...\n")

                .get_inits_spectral_sparse(x, G, D, symmetrize, normalized, verbose)

            }
        )
    }

    res[[3]] = as.integer(res[[3]])
    names(res) = c(
        "centroids",
        "eigvecs",
        "clusters",
        "dist",
        "convergence"
    )

    return(res)

}

### EOF ###