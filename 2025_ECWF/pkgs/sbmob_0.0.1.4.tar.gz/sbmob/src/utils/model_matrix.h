#ifndef MODEL_MATRIX_H
#define MODEL_MATRIX_H

#include <RcppEigen.h>
#include "misc.h"

typedef Eigen::SparseMatrix<double> SpMat;
typedef Eigen::SparseVector<double> SpVec;
typedef Eigen::Triplet<double> Trip;

//' Creates a long vector from matrix by extracting and concatenating
//' off-diagonal elements
//' 
//' @param x eigen matrix of dimension n X n
//' @return Vector of length n * (n - 1) with columns of x concatenated while dropping diagonal elements
inline Eigen::VectorXd mat_offdiag_to_vec(const Eigen::MatrixXd &x) {
    
    int N = x.cols();
    
    // flatten
    Eigen::Map<const Eigen::VectorXd> y_full(x.data(), x.size());
    
    // new vector without diagonals
    Eigen::VectorXd y(N * (N - 1));
    for (int j = 0; j < N - 1; ++j)
        y.segment(j * N, N) = y_full.segment(j * (N + 1) + 1, N);
    
    return y;
    
}

//' Creates a long vector from matrix by extracting and concatenating
//' off-diagonal elements
//' 
//' @param x eigen matrix of dimension n X n
//' @return Vector of length n * (n - 1) with columns of x concatenated while dropping diagonal elements
inline Eigen::VectorXd mat_offdiag_to_vec(const SpMat &x) {
    
    int N = x.cols();
    
    // new vector without diagonals
    Eigen::VectorXd y = Eigen::VectorXd::Zero(N * (N - 1));
    int cc(0L);
    for (int j = 0; j < x.outerSize(); ++j)
        for (SpMat::InnerIterator i(x, j); i; ++i)
            if (i.row() != j) {
                y(j * N + i.row() - cc) = i.value();
            } else {
                ++cc;
            }
            
    return y;
    
}


//' creating model matrix for irls algorithm
//' 
//' @param z block membership vector
//' @param zero_indx indices of reg params to be set to zero
//' @return returns a model matrix (the X matrix) to be used in WLS regression of IRLS algrithm
inline SpMat model_matrix(const Eigen::ArrayXi& z, const Eigen::ArrayXi& zero_indx) {
    
    int N = z.size();
    int G = uniqueN_z(z);
    int N_zero = zero_indx.size();
    int K = 2 * (N - N_zero) + G * G;
    
    std::vector<Trip> tlist;
    tlist.reserve(2 * (N - N_zero) * (N - 1) + N * (N - 1));
    
    int cc(0L);
    int col_indx(0L);
    
    for (int j = 0; j < N; ++j) {
        
        bool nzero_j = !(zero_indx == j).any();
        
        for (int i = 0; i < N; ++i) {
            
            if (i != j) {
                
                // column-effects
                if (nzero_j)
                    tlist.push_back(Trip(cc, N - N_zero + col_indx, 1));
                
                // row-effects
                if (!(zero_indx == i).any()) {
                    
                    tlist.push_back(Trip(cc, i - (zero_indx < i).count(), 1));
                    
                }
                
                // block effects
                tlist.push_back(Trip(cc, 2 * (N - N_zero) + G * z(i) + z(j), 1));
                
                ++cc;
                
            }
            
        }
        
        if (nzero_j)
            ++col_indx;
        
    }
    
    SpMat mmat(N * (N - 1), K);
    mmat.setFromTriplets(tlist.begin(), tlist.end());
    
    return mmat;
    
}

#endif
